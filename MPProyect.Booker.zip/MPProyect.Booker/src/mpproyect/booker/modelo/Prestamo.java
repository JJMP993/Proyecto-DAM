package mpproyect.booker.modelo;

import java.util.Date;

/**
 * La clase Prestamo representa un préstamo de un libro a un cliente en la biblioteca.
 * Registra la información sobre el libro prestado, el cliente, y las fechas del préstamo.
 * tiene getters y setters de todos sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Prestamo {
    
    /**
     * Identificador único del préstamo.
     */
    private int id;
    
    /**
     * Identificador del libro prestado.
     */
    private int idLibro;
    
    /**
     * Identificador del cliente que ha pedido el préstamo.
     */
    private int idCliente;
    
    /**
     * Fecha de inicio del préstamo.
     */
    private Date fecha;
    
    /**
     * Fecha en que se debe devolver el libro.
     */
    private Date fechaLimite;

    public Prestamo() {
    }

    public Prestamo(int id, int idLibro, int idCliente, Date fecha, Date fechaLimite) {
        this.id = id;
        this.idLibro = idLibro;
        this.idCliente = idCliente;
        this.fecha = fecha;
        this.fechaLimite = fechaLimite;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdLibro() {
        return idLibro;
    }

    public void setIdLibro(int idLibro) {
        this.idLibro = idLibro;
    }

    public int getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(int idCliente) {
        this.idCliente = idCliente;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getFechaLimite() {
        return fechaLimite;
    }

    public void setFechaLimite(Date fechaLimite) {
        this.fechaLimite = fechaLimite;
    }
    
    
    
}

package mpproyect.booker.modelo;

import java.util.Date;

/**
 * La clase Trabajador extiende de Persona y representa a un trabajador de la biblioteca.
 * Contiene información adicional como el nivel de rol y el estado de actividad del trabajador.
 * tiene getters y setters de todos sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Trabajador extends Persona{
    
    /**
     * Usuario de inicio de sesión del trabajador
     */
    private String usuario;
    
    /**
     * Contraseña de inicio de sesión del trabajador
     */
    private String password;
    
    /**
     * Nivel de rol del trabajador (Del 1 al 5).
     */
    private int rol;
    /**
     * Indica si el trabajador está activo.
     */
    private boolean estaActivo;

    public Trabajador() {
    }

    public Trabajador(String usuario, String password, int rol, boolean estaActivo, int id, String dni, String nombre, String apellidos, String direccion, Date nacimiento, String telefono, String email) {
        super(id, dni, nombre, apellidos, direccion, nacimiento, telefono, email);
        this.usuario = usuario;
        this.password = password;
        this.rol = rol;
        this.estaActivo = estaActivo;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getRol() {
        return rol;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }

    public boolean isEstaActivo() {
        return estaActivo;
    }

    public void setEstaActivo(boolean estaActivo) {
        this.estaActivo = estaActivo;
    }
    
    
    
    
    
}

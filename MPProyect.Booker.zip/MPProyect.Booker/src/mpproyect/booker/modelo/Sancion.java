package mpproyect.booker.modelo;

import java.util.Date;

/**
 * La clase Sancion representa una sanción impuesta a un cliente por incumplir las normas de la biblioteca.
 * Contiene información sobre el préstamo relacionado, el cliente sancionado, y la duración de la sanción.
 * tiene getters y setters de todos sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Sancion {
    
    /**
     * Identificador único de la sanción.
     */
    private int id;
    
    /**
     * Identificador del cliente sancionado.
     */
    private int idCliente;
    
    /**
     * DNI del cliente sancionado.
     */
    private String dni;
    
    /**
     * Indica si el motivo de la sanción
     */
    private String motivo;
    
    /**
     * Fecha de inicio de la sanción.
     */
    private Date fechaSancion;
    
    /**
     * Fecha de finalización de la sanción.
     */
    private Date finSancion;
    
    /**
     * Indica si la sanción está activa.
     */
    private boolean estaActivo;

    public Sancion() {
    }

    public Sancion(int id, int idUsuario, String dni, String motivo, Date fechaSancion, Date finSancion, boolean estaActivo) {
        this.id = id;
        this.idCliente = idUsuario;
        this.dni = dni;
        this.motivo = motivo;
        this.fechaSancion = fechaSancion;
        this.finSancion = finSancion;
        this.estaActivo = estaActivo;
    }
    
    

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getIdUsuario() {
        return idCliente;
    }

    public void setIdUsuario(int idUsuario) {
        this.idCliente = idUsuario;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getMotivo() {
        return motivo;
    }

    public void setMotivo(String motivo) {
        this.motivo = motivo;
    }

    public Date getFechaSancion() {
        return fechaSancion;
    }

    public void setFechaSancion(Date fechaSancion) {
        this.fechaSancion = fechaSancion;
    }

    public Date getFinSancion() {
        return finSancion;
    }

    public void setFinSancion(Date finSancion) {
        this.finSancion = finSancion;
    }

    public boolean isEstaActivo() {
        return estaActivo;
    }

    public void setEstaActivo(boolean estaActivo) {
        this.estaActivo = estaActivo;
    }
    
    

    
}

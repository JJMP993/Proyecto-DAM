package mpproyect.booker.modelo;

import java.util.Date;

/**
 * La clase Cliente extiende de Persona y representa a un cliente que interactúa con la biblioteca.
 * Un cliente puede realizar préstamos y estar sujeto a sanciones dependiendo de su comportamiento.
 * tiene getters y setters de todos sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Cliente extends Persona{
    
    /**
     * booleano que si es true el cliente esta castigado y no puede pedir prestamos.
     */
    private boolean estaCastigado;
    
    /**
     * booleano que si es true el cliente tiene prohibido los prestamos hasta que
     * se le desbloquee manualmente.
     */
    private boolean estaVetado;
    
    /**
     * numero entero que determina los prestamos simultaneos del cliente
     */
    private int prestamosActivos;
    
    /**
     * Numero entero que determina el numero total de sanciones del cliente
     */
    private int numeroSanciones;

    /**
     * Constructor con todos los atributos, primero van los caracteristicos
     * al cliente
     * @param estaCastigado int
     * @param estaVetado boolean
     * @param prestamosActivos int
     * @param numeroSanciones int
     * @param id int
     * @param dni String
     * @param nombre String
     * @param apellidos String
     * @param direccion String
     * @param nacimiento Date
     * @param telefono String
     * @param email String
     */
    public Cliente(boolean estaCastigado, boolean estaVetado, int prestamosActivos, int numeroSanciones, int id, String dni, String nombre, String apellidos, String direccion, Date nacimiento, String telefono, String email) {
        super(id, dni, nombre, apellidos, direccion, nacimiento, telefono, email);
        this.estaCastigado = estaCastigado;
        this.estaVetado = estaVetado;
        this.prestamosActivos = prestamosActivos;
        this.numeroSanciones = numeroSanciones;
    }

    /**
     * Constructor con solo los parametros de cliente
     * @param estaCastigado boolean
     * @param estaVetado boolean
     * @param prestamosActivos int
     * @param numeroSanciones int
     */
    public Cliente(boolean estaCastigado, boolean estaVetado, int prestamosActivos, int numeroSanciones) {
        this.estaCastigado = estaCastigado;
        this.estaVetado = estaVetado;
        this.prestamosActivos = prestamosActivos;
        this.numeroSanciones = numeroSanciones;
    }
    
    
    /**
     * Contructor sin parametros
     */
    public Cliente() {
    }

     /**
     * Indica si el cliente está penalizado temporalmente.
     * @return true si el cliente está penalizado temporalmente, false en caso contrario.
     */
    public boolean isEstaCastigado() {
        return estaCastigado;
    }

    /**
     * Establece si el cliente está penalizado temporalmente.
     * @param estaCastigado true para penalizar temporalmente al cliente, false para lo contrario.
     */
    public void setEstaCastigado(boolean estaCastigado) {
        this.estaCastigado = estaCastigado;
    }

    /**
     * Indica si el cliente está penalizado de forma permanente.
     * @return true si el cliente está penalizado permanentemente, false en caso contrario.
     */
    public boolean isEstaVetado() {
        return estaVetado;
    }

    /**
     * Establece si el cliente está penalizado permanentemente.
     * @param estaVetado true para penalizar permanentemente al cliente, false para lo contrario.
     */
    public void setEstaVetado(boolean estaVetado) {
        this.estaVetado = estaVetado;
    }

    /**
     * Obtiene el número de préstamos activos del cliente.
     * @return el número de préstamos activos.
     */
    public int getPrestamosActivos() {
        return prestamosActivos;
    }

    /**
     * Establece el número de préstamos activos del cliente.
     * @param prestamosActivos número de préstamos activos.
     */
    public void setPrestamosActivos(int prestamosActivos) {
        this.prestamosActivos = prestamosActivos;
    }

    /**
     * Obtiene el número de sanciones del cliente.
     * @return el número de sanciones.
     */
    public int getNumeroSanciones() {
        return numeroSanciones;
    }

    /**
     * Establece el número de sanciones del cliente.
     * @param numeroSanciones número de sanciones.
     */
    public void setNumeroSanciones(int numeroSanciones) {
        this.numeroSanciones = numeroSanciones;
    }
    
    
    
    
    
}

    

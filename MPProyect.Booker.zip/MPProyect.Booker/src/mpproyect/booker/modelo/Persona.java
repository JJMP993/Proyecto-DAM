/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mpproyect.booker.modelo;

import java.util.Date;

/**
 * Clase que generaliza a una persona fisica tiene getters y setters de todos
 * sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Persona {
    
    /**
     * Numero entero que identifica a la persona
     */
    private int id;
    
    /**
     * String que guarda el numero de identificación nacional
     */
    private String dni;
    
    /**
     * Nombre de la persona
     */
    private String nombre;
    
    /**
     * Apellidos de la persona
     */
    private String apellidos;
    
    /**
     * Dirección donde vive la persona
     */
    private String direccion;
    
    /**
     * Fecha de nacimiento de la persona
     */
    private Date nacimiento;
    
    /**
     * Numero de telefono para localizar a la persona
     */
    private String telefono;
    
    /**
     * Correo electronico de la persona
     */
    private String email;

    /**
     * Constructor sin parametros
     */
    public Persona() {
    }
    
    
    /**
     * Constructor con todos los atributos de la persona
     * @param id id
     * @param dni dni
     * @param nombre nombre
     * @param apellidos apellidos
     * @param direccion direccion
     * @param nacimiento fecha nacimiento
     * @param telefono numero de telefono
     * @param email correo electronico.
     */
    public Persona(int id, String dni, String nombre, String apellidos, String direccion, Date nacimiento, String telefono, String email) {
        this.id = id;
        this.dni = dni;
        this.nombre = nombre;
        this.apellidos = apellidos;
        this.direccion = direccion;
        this.nacimiento = nacimiento;
        this.telefono = telefono;
        this.email = email;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getDni() {
        return dni;
    }

    public void setDni(String dni) {
        this.dni = dni;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public Date getNacimiento() {
        return nacimiento;
    }

    public void setNacimiento(Date nacimiento) {
        this.nacimiento = nacimiento;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    
}

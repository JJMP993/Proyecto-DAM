package mpproyect.booker.modelo;

import java.util.Date;

/**
 * La clase Libro representa un libro en la biblioteca.
 * Contiene información sobre el título, autor, ISBN, y el estado del libro en relación a su disponibilidad.
 * tiene getters y setters de todos sus atributos y constructor con todos y sin ningún parametro.
 * @author José Javier Morillas Pérez
 */
public class Libro {

    /**
     * Identificador único del libro.
     */
    private int id;
    
    /**
     * Título del libro.
     */
    private String titulo;
    
    /**
     * Autor del libro.
     */
    private String autor;
    
    /**
     * ISBN del libro.
     */
    private String isbn;
    
    /**
     * Fecha de publicación del libro.
     */
    private Date fechaAdquisicion;
    
    /**
     * Indica si el libro es prestable o no.
     */
    private boolean esPrestable;
    
    /**
     * Indica si el libro está actualmente en préstamo.
     */
    private boolean enPrestamo;
    
    /**
     * Estado del libro (por ejemplo: nuevo, usado, dañado, etc.).
     */
    private String estado;

    public Libro() {
    }

    public Libro(int id, String titulo, String autor, String isbn, Date fechaAdquisicion, boolean esPrestable, boolean enPrestamo, String estado) {
        this.id = id;
        this.titulo = titulo;
        this.autor = autor;
        this.isbn = isbn;
        this.fechaAdquisicion = fechaAdquisicion;
        this.esPrestable = esPrestable;
        this.enPrestamo = enPrestamo;
        this.estado = estado;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public Date getFechaAdquisicion() {
        return fechaAdquisicion;
    }

    public void setFechaAdquisicion(Date fechaAdquisicion) {
        this.fechaAdquisicion = fechaAdquisicion;
    }

    public boolean isEsPrestable() {
        return esPrestable;
    }

    public void setEsPrestable(boolean esPrestable) {
        this.esPrestable = esPrestable;
    }

    public boolean isEnPrestamo() {
        return enPrestamo;
    }

    public void setEnPrestamo(boolean enPrestamo) {
        this.enPrestamo = enPrestamo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    

}

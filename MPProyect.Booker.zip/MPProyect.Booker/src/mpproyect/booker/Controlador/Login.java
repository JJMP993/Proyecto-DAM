/*
 * Paquete controlador: contiene las clases que se encargar de la lógica de
 * la aplicación
 */
package mpproyect.booker.Controlador;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import java.sql.*;
import java.sql.SQLException;

import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Clase controladora que se encarga de la conexión a la bbdd, validación de 
 * usuarios, gestión de permisos y configuración de la aplicacion, Tambien hace
 * los checkeos de que los campos introducidos son correctos.
 *
 * @author José Javier Morillas Pérez
 */
public class Login {

    /**
     * Url de conexión a base de datos mysql
     */
    private String UrlBbdd;

    /**
     * Usuario de la BBDD
     */
    private String usuarioBbdd;

    /**
     * Contraseña del usuario de la BBDD
     */
    private String passwordBbdd;

    /**
     * Usuario para conectarse a la app
     */
    private String usuario;

    /**
     * Contraseña para conectarse a la app
     */
    private String password;

    /**
     * Indica si se ha pasado el proceso de identificación de usuario
     */
    private boolean estaConectado;

    /**
     * Numero entero que indica el identificador del rol
     */
    private int rol;
    /**
     * Ruta al archivo para guardar las url de las BBDD
     */
    private static String ULR_ARCHIVO_BASES_DE_DATOS = ".\\src\\data\\bases_de_datos.txt";

    /**
     * Constructor por defecto, pone estaConectado en false;
     */
    public Login() {
        this.estaConectado = false;
    }

    public Login(String UrlBbdd, String usuarioBbdd, String passwordBbdd, String usuario, String password, boolean estaConectado, int rol) {
        this.UrlBbdd = UrlBbdd;
        this.usuarioBbdd = usuarioBbdd;
        this.passwordBbdd = passwordBbdd;
        this.usuario = usuario;
        this.password = password;
        this.estaConectado = estaConectado;
        this.rol = rol;
    }

    public String getUrlBbdd() {
        return UrlBbdd;
    }

    public void setUrlBbdd(String UrlBbdd) {
        this.UrlBbdd = UrlBbdd;
    }

    public String getUsuarioBbdd() {
        return usuarioBbdd;
    }

    public void setUsuarioBbdd(String usuarioBbdd) {
        this.usuarioBbdd = usuarioBbdd;
    }

    public String getPasswordBbdd() {
        return passwordBbdd;
    }

    public void setPasswordBbdd(String passwordBbdd) {
        this.passwordBbdd = passwordBbdd;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isEstaConectado() {
        return estaConectado;
    }

    public void setEstaConectado(boolean estaConectado) {
        this.estaConectado = estaConectado;
    }

    public int getRol() {
        return rol;
    }

    public void setRol(int rol) {
        this.rol = rol;
    }

    /**
     * Metodo que cifraen SHA256, se utilizará para cifrar contraseñas y
     * consultar en el login del usuario
     *
     * @param cadena String Mensaje a cifrar.
     * @return String Mensaje cifrado en SHA256 o un string "error"
     */
    public static String cifradoSHA256(String cadena) {
        StringBuffer cifradoSHA256 = new StringBuffer();

        MessageDigest mdigestSHA256; // 
        try {
            //conseguimos la instancia que cifra en SHA256
            mdigestSHA256 = MessageDigest.getInstance("sha-256");
            //Se cifra byte a byte
            byte[] cifrado = mdigestSHA256.digest(cadena.getBytes());

            //Lo guardamos en un StringBuffer
            for (int i = 0; i < cifrado.length; i++) {
                cifradoSHA256.append(Integer.toHexString(0xFF & cifrado[i]));

            }
        } catch (NoSuchAlgorithmException e) {
            return "error";
        }
        return cifradoSHA256.toString();

    }
    
    /**
     * Metodo que guarda la url en el fichero bases_de_datos y evita duplicados
     * comprobando el archivo previamente.
     *
     * @param url Url a guardar en fichero.
     * @throws FileNotFoundException Error si no hay fichero
     * @throws IOException Error en la entrada o salida al archivo
     */
    public void guardarUrlBbdd(String url) throws FileNotFoundException, IOException {
        File fich = new File(ULR_ARCHIVO_BASES_DE_DATOS);
        String lineaFichero;
        boolean guardar = true;
        if (!fich.isFile()) {
            fich.createNewFile();
        }
        //Establecemos flujo de lectura
        FileReader fr = new FileReader(fich);
        BufferedReader bf = new BufferedReader(fr);

        //leemos cada linea y si coincide la url no se guarda
        lineaFichero = bf.readLine();
        while (lineaFichero != null) {
            if (url.equals(lineaFichero)) {
                guardar = false; // si encuentra esa url no lo guarda.
            }
            lineaFichero = bf.readLine();
        }
        bf.close();
        fr.close();

        if (guardar) {
            //Se escribe la linea a final del documento y pone un salto de linea.
            FileWriter fw = new FileWriter(fich, true);
            fw.write(url + "\n");
            fw.close();
        }

    }
    
    /**
     * Metodo que carga las url de base de datos como opciones en el comboBox a
     * partir de los datos del fichero bases_de_datos
     *
     * @param comboBox elemento visual a cambiar
     * @throws FileNotFoundException Error si no hay fichero
     * @throws IOException Error en la entrada o salida al archivo
     */
    public void cargarUrl(javax.swing.JComboBox<String> comboBox) throws FileNotFoundException, IOException {
        File fich = new File(ULR_ARCHIVO_BASES_DE_DATOS);
        String lineaFichero;
        if (!fich.isFile()) {
            fich.createNewFile();
        }
        FileReader fr = new FileReader(fich);
        BufferedReader bf = new BufferedReader(fr);
        lineaFichero = bf.readLine();
        while (lineaFichero != null) {
            //Por cada linea leida se crea una opción en el comboBox
            comboBox.addItem(lineaFichero);
            lineaFichero = bf.readLine();
        }
        bf.close();
        fr.close();

    }


    
    /**
     * Metodo que borra una url del archivo de bases_de_datos que coincide con
     * la opción seleccionada en el comboBox, también borra esa opción en el
     * comboBox. El metodo guarda en un ArrayList todos los que no coincide con
     * la entrada que se quiere borrar y reescribe todo el fichero sin esa
     * opción
     *
     * @param comboBox elemento grafico a cambiar
     * @return Booleano que indica si se ha borrado o no
     * @throws FileNotFoundException Error por no encontrar el fichero
     * @throws IOException Error de entrada y salida de la aplicación al fichero
     */
    public boolean borrarUrl(javax.swing.JComboBox<String> comboBox) throws FileNotFoundException, IOException {
        //el elemento a borrar primero se selecciona.
        Object enlaceBorrar = comboBox.getSelectedItem();
        String sEnlaceBorrar = enlaceBorrar.toString();

        File fich = new File(ULR_ARCHIVO_BASES_DE_DATOS);
        String lineaFichero;
        //Creamos ArrayList para guardar las lineas que no queremos borrar
        ArrayList<String> textoFichero = new ArrayList<String>();
        boolean borrar = false;

        if (!fich.isFile()) {
            fich.createNewFile();
        }
        //abrimos flujo de lectura
        FileReader fr = new FileReader(fich);
        BufferedReader bf = new BufferedReader(fr);

        //Leemos cada linea en busca de lo que hay que borrar
        lineaFichero = bf.readLine();
        while (lineaFichero != null) {
            //Si lo encuentra borrar se pone en true.
            if (sEnlaceBorrar.equals(lineaFichero)) {
                borrar = true; //Se encuentra el elemento en el archivo
            } else {
                //si no se guarda la linea en el array
                textoFichero.add(lineaFichero);
            }
            lineaFichero = bf.readLine();
        }
        bf.close();
        fr.close();

        if (borrar) { //Solo si encontramos la url en el archivo
            boolean cambioModoFW = false; //Para borrar todo primero ponemos en false append
            FileWriter fw = new FileWriter(fich, cambioModoFW);
            for (int i = 0; i < textoFichero.size(); i++) {
                fw.write(textoFichero.get(i) + "\n");
                //la primera vez borra el fichero con la linea que escribe, despues se vuelve append
                if (!cambioModoFW) {
                    cambioModoFW = true;
                    fw.close();
                    //Cambiamos el append a true para escribir al final del texto del fichero
                    fw = new FileWriter(fich, cambioModoFW);
                }
            }
            textoFichero.clear();
            fw.close();
            int itemABorrar = comboBox.getSelectedIndex();
            //borramos del comboBox la opción
            comboBox.removeItemAt(itemABorrar);
        }
        return borrar;
    }
    
    /**
     * Metodo para comprobar que el usuario y la contraseña corresponden con un
     * usuario, además establece los atributos de la clase estaConectado a true
     * si existe el usuario y además recoge el nivelRol en el atributo rol
     *
     * @param conexion conexión a la base de datos
     */
    public void conectarse(Connection conexion) {
        Connection conection = conexion;
        PreparedStatement sentencia = null;
        ResultSet usuarioEncontrado = null;
        //Se cifra la contraseña para la consulta.
        String passwordCifrada = cifradoSHA256(this.password);
        //Creamos PreparedStatement para poner la sentencia con parametros
        String sentenciabusqueda = "SELECT nivelRol "
                + "FROM Trabajador WHERE "
                + "activo=true AND nombreUsuario=? AND password=?";
        try {
            sentencia = conection.prepareStatement(sentenciabusqueda);

            sentencia.setString(1, usuario);
            sentencia.setString(2, passwordCifrada);

            //Ejecutamos consulta y la recogemos en un ResultSet
            usuarioEncontrado = sentencia.executeQuery();

            if (usuarioEncontrado.next()) {
                //Si hay usuario, nos guardamos su nivelRol
                int resultado = 0;

                resultado = usuarioEncontrado.getInt("nivelRol");

                //Ponemos a true estaConectado y ponemos el nivel de rol recibido.
                this.estaConectado = true;
                this.rol = resultado;

            }
            usuarioEncontrado.close();

            sentencia.close();
        } catch (SQLException ex) {
            Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            if (conection != null) {
                try {
                    conection.close();
                    conection = null;
                } catch (SQLException ex) {
                    Logger.getLogger(Login.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
    }

   /**
     * Metodo que comprueba si el administrador esta activo
     *
     * @param conexion Conexión a la BBDD sql.
     * @return Si no es la primera vez retorna true, si es la primera vez false
     * @throws SQLException Error en sentencia
     */
    public boolean comprobarAdminActivo(Connection conexion) throws SQLException {
        boolean esActivo = false;
        Connection conection = conexion;
        PreparedStatement sentencia = null;
        //Comprobamos el estado del usuario administrador con nivel de rol 5
        String sentenciabusqueda = "select activo from Trabajador where nivelRol =5";
        sentencia = conection.prepareStatement(sentenciabusqueda);
        ResultSet usuarioEncontrado = sentencia.executeQuery();
        if (usuarioEncontrado.next()) {

            //si activo es true esta activado, si no hay que activarlo con otro método.
            esActivo = usuarioEncontrado.getBoolean("activo");
        }
        usuarioEncontrado.close();
        sentencia.close();
        if (conection != null) {
            conection.close();
        }
        return esActivo;
    }
    
    /**
     * Método para activar el usuario administrador, se le cambia los datos de
     * inicio de sesión.
     *
     * @param conexion Conexión a la BBDD sql.
     * @return 1 si activa al administrador 0 si no.
     * @throws SQLException Error en la sentencia.
     */
    public int cambiarAdmin(Connection conexion) throws SQLException {
        //Se cifra la contraseña
        String passwordCifrada = cifradoSHA256(this.password);
        String sql = "UPDATE Trabajador "
                + "SET nombreUsuario = ?, password = ?, activo = true "
                + "WHERE nivelRol = 5";
        PreparedStatement sentencia = null;
        int filasActualizadas = 0;

        //Se introduce los datos necesarios para el UPDATE
        sentencia = conexion.prepareStatement(sql);
        sentencia.setString(1, usuario);
        sentencia.setString(2, passwordCifrada);

        filasActualizadas = sentencia.executeUpdate();
        sentencia.close();
        this.usuario = null;
        this.password = null;

        return filasActualizadas;
    }


    /**
     * Metodo que establece conexión con la base de datos.
     *
     * @return Objeto de tipo Connection
     * @throws SQLException Error en sentencia
     * @throws ClassNotFoundException Error en el driver de conexión
     */
    public Connection getConexionBBDD() throws SQLException, ClassNotFoundException {
        Connection conexion = null;
        Class.forName("com.mysql.jdbc.Driver");
        conexion = DriverManager.getConnection(this.UrlBbdd,
                this.usuarioBbdd, this.passwordBbdd);
        return conexion;
    }

    /**
     * Metodo que recibe los elementos que activan los distintos botones de la
     * interfaz VentanaPrincipal
     *
     * @param prestamos botón prestamos
     * @param devoluciones botón devoluciones
     * @param libros botón libros
     * @param usuarios botón clientes y personal
     * @param sanciones botón Sanciones
     * @param config botón Configuración
     * @param permisos botón Permisos
     * @param conexion Conexion a la base de datos
     * @throws SQLException Error en la sentencia
     */
    public void permisosPrincipal(javax.swing.JButton prestamos, javax.swing.JButton devoluciones,
            javax.swing.JButton libros, javax.swing.JButton usuarios,
            javax.swing.JButton sanciones, javax.swing.JButton config,
            javax.swing.JButton permisos, Connection conexion) throws SQLException {
        Connection conection = conexion;
        PreparedStatement sentencia = null;
        boolean gestionUsuarios = false;
        boolean generarInformes = false;
        boolean gestionColecciones = false;
        boolean perdonarSanciones = false;
        boolean gestionConfiguracion = false;
        boolean gestionTrabajadoresPermisos = false;
        String sentenciabusqueda = "SELECT gestionUsuarios, generarInformes, "
                + "gestionColecciones, perdonarSanciones, gestionConfiguracion, "
                + "gestionTrabajadoresPermisos "
                + "FROM RolesFunciones WHERE nivelRol=?";
        sentencia = conection.prepareStatement(sentenciabusqueda);

        sentencia.setInt(1, rol);

        //Ejecutamos consulta y la recogemos en un ResultSet
        ResultSet permisosEncontrados = sentencia.executeQuery();
        if (permisosEncontrados.next()) {
            //una vez encontrados establecemos el valor del permiso.
            gestionUsuarios = permisosEncontrados.getBoolean("gestionUsuarios");
            generarInformes = permisosEncontrados.getBoolean("generarInformes");
            gestionColecciones = permisosEncontrados.getBoolean("gestionColecciones");
            perdonarSanciones = permisosEncontrados.getBoolean("perdonarSanciones");
            gestionConfiguracion = permisosEncontrados.getBoolean("gestionConfiguracion");
            gestionTrabajadoresPermisos = permisosEncontrados.getBoolean("gestionTrabajadoresPermisos");

            //activamos y desactivamos los botones dependiendo de los siguientes permisos:
            prestamos.setEnabled(gestionUsuarios);
            devoluciones.setEnabled(gestionUsuarios);
            libros.setEnabled(generarInformes);
            usuarios.setEnabled(gestionUsuarios);
            sanciones.setEnabled(perdonarSanciones);
            config.setEnabled(gestionConfiguracion);
            permisos.setEnabled(gestionTrabajadoresPermisos);

        }
        permisosEncontrados.close();
        sentencia.close();

    }

    /**
     * Metodo que recibe los elementos que activan los distintos botones de la
     * interfaz VentanaClientesTrabajadores
     *
     * @param buscar1 Botón buscar.
     * @param buscar2 Botón buscar.
     * @param buscar3 Botón buscar.
     * @param buscar4 Botón buscar.
     * @param buscar5 Botón buscar.
     * @param buscar6 Botón buscar.
     * @param buscar7 Botón buscar.
     * @param buscar8 Botón buscar.
     * @param crearCliente Botón crearCliente.
     * @param modificarCliente Botón modificarCliente.
     * @param eliminarCliente Botón eliminarCliente.
     * @param crearTrabajador Botón crearTrabajador.
     * @param modificarTrabajador Botón modificarTrabajador.
     * @param eliminarTrabajador Botón eliminarTrabajador.
     * @param conexion Conexión a la BBDD.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public void permisosClientesTrabajadores(javax.swing.JButton buscar1, javax.swing.JButton buscar2,
            javax.swing.JButton buscar3, javax.swing.JButton buscar4,
            javax.swing.JButton buscar5, javax.swing.JButton buscar6,
            javax.swing.JButton buscar7, javax.swing.JButton buscar8,
            javax.swing.JButton crearCliente, javax.swing.JButton modificarCliente,
            javax.swing.JButton eliminarCliente, javax.swing.JButton crearTrabajador,
            javax.swing.JButton modificarTrabajador, javax.swing.JButton eliminarTrabajador,
            Connection conexion) throws SQLException {
        Connection conection = conexion;
        PreparedStatement sentencia = null;
        boolean gestionUsuarios = false;
        boolean generarInformes = false;
        boolean gestionTrabajadoresPermisos = false;
        //Consultamos los permisos necesarios en la ventana.
        String sentenciabusqueda = "SELECT gestionUsuarios, generarInformes, gestionTrabajadoresPermisos"
                + " FROM RolesFunciones WHERE nivelRol=?";
        sentencia = conection.prepareStatement(sentenciabusqueda);

        sentencia.setInt(1, rol);

        //Ejecutamos consulta y la recogemos en un ResultSet
        ResultSet permisosEncontrados = sentencia.executeQuery();
        if (permisosEncontrados.next()) {
            //una vez encontrados establecemos el valor del permiso.
            gestionUsuarios = permisosEncontrados.getBoolean("gestionUsuarios");
            generarInformes = permisosEncontrados.getBoolean("generarInformes");
            gestionTrabajadoresPermisos = permisosEncontrados.getBoolean("gestionTrabajadoresPermisos");

            //activamos y desactivamos los botones según los siguientes permisos:
            buscar1.setEnabled(generarInformes);
            buscar2.setEnabled(generarInformes);
            buscar3.setEnabled(generarInformes);
            buscar4.setEnabled(generarInformes);
            buscar5.setEnabled(generarInformes);
            buscar6.setEnabled(generarInformes);
            buscar7.setEnabled(generarInformes);
            buscar8.setEnabled(generarInformes);
            crearCliente.setEnabled(gestionUsuarios);
            modificarCliente.setEnabled(gestionUsuarios);
            eliminarCliente.setEnabled(gestionTrabajadoresPermisos);
            crearTrabajador.setEnabled(gestionTrabajadoresPermisos);
            modificarTrabajador.setEnabled(gestionTrabajadoresPermisos);
            eliminarTrabajador.setEnabled(gestionTrabajadoresPermisos);

        }
        permisosEncontrados.close();
        sentencia.close();

    }

    /**
     * Metodo que recibe los elementos que activan los distintos botones de la
     * interfaz VentanaDevolucion o VentanaPrestamos.
     *
     * @param buscar1 Botón buscar.
     * @param buscar2 Botón buscar.
     * @param buscar3 Botón buscar.
     * @param buscar4 Botón buscar.
     * @param accion botón devolver o prestar.
     * @param conexion Conexión a la BBDD.
     * @throws SQLException Error a conectar a la BBDD.
     */
    public void permisosPrestamoDevolucion(javax.swing.JButton buscar1, javax.swing.JButton buscar2,
            javax.swing.JButton buscar3, javax.swing.JButton buscar4, javax.swing.JButton accion,
            Connection conexion) throws SQLException {
        boolean gestionUsuarios = false;
        boolean generarInformes = false;
        String sentenciabusqueda = "SELECT gestionUsuarios, generarInformes "
                + "FROM RolesFunciones "
                + "WHERE nivelRol=?";

        PreparedStatement sentencia = null;
        sentencia = conexion.prepareStatement(sentenciabusqueda);
        sentencia.setInt(1, rol);

        ResultSet permisosEncontrados = sentencia.executeQuery();
        if (permisosEncontrados.next()) {
            //una vez encontrados establecemos el valor del permiso.
            gestionUsuarios = permisosEncontrados.getBoolean("gestionUsuarios");
            generarInformes = permisosEncontrados.getBoolean("generarInformes");

            //Establecemos los botones según los siguientes permisos.
            buscar1.setEnabled(generarInformes);
            buscar2.setEnabled(generarInformes);
            buscar3.setEnabled(generarInformes);
            buscar4.setEnabled(generarInformes);
            accion.setEnabled(gestionUsuarios);
        }
        permisosEncontrados.close();
        sentencia.close();
    }

    /**
     * Metodo que recibe los elementos que activan los distintos botones de la
     * interfaz VentanaColecciones.
     *
     * @param buscar Botón buscar
     * @param buscar2 Botón Buscar
     * @param buscar3 Botón Buscar
     * @param buscar4 Botón Buscar
     * @param crearLibro Botón crear Libro
     * @param eliminarLibro Botón eliminar libro.
     * @param modificarLibro Botón modificar libro.
     * @param conexion Conexión a la BBDD
     * @throws SQLException Error de conexión a la BBDD
     */
    public void permisosColecciones(javax.swing.JButton buscar, javax.swing.JButton buscar2,
            javax.swing.JButton buscar3, javax.swing.JButton buscar4,
            javax.swing.JButton crearLibro, javax.swing.JButton eliminarLibro,
            javax.swing.JButton modificarLibro, Connection conexion) throws SQLException {
        Connection conection = conexion;
        PreparedStatement sentencia = null;
        boolean generarInformes = false;
        boolean gestionColecciones = false;
        String sentenciabusqueda = "SELECT generarInformes, gestionColecciones "
                + "FROM RolesFunciones WHERE nivelRol=?";
        sentencia = conection.prepareStatement(sentenciabusqueda);

        sentencia.setInt(1, rol);

        //Ejecutamos consulta y la recogemos en un ResultSet
        ResultSet permisosEncontrados = sentencia.executeQuery();
        if (permisosEncontrados.next()) {
            //una vez encontrados establecemos el valor del permiso.
            generarInformes = permisosEncontrados.getBoolean("generarInformes");
            gestionColecciones = permisosEncontrados.getBoolean("gestionColecciones");

            //activamos y desactivamos los botones según los siguientes permisos:
            buscar.setEnabled(generarInformes);
            buscar2.setEnabled(generarInformes);
            buscar3.setEnabled(generarInformes);
            buscar4.setEnabled(generarInformes);
            crearLibro.setEnabled(gestionColecciones);
            eliminarLibro.setEnabled(gestionColecciones);
            modificarLibro.setEnabled(gestionColecciones);

        }
        permisosEncontrados.close();
        sentencia.close();

        if (conection != null) {
            conection.close();
        }

    }

    //Comprobaciones
    /**
     * Metodo que prueba que se cumpla las siguientes condiciones en
     * VentanaCrearUsuarioAdmin
     *
     * @param usuario 5 - 100 carácteres.
     * @param password 5 - 15 carácteres.
     * @return true si cumple condiciones , false si no las cumple.
     */
    public boolean checkCrearAdmin(String usuario, String password) {
        boolean todoBien = true;
        if ((usuario.length() < 5) || (usuario.length() > 100)
                || (password.length() > 15)
                || (password.length() < 5)) {
            todoBien = false;
        }
        return todoBien;
    }

    /**
     * Metodo que prueba que se cumpla las siguientes condiciones en
     * VentanaCrearLibro y VentanaModificarLibro:
     *
     * @param titulo 1-255 carácteres.
     * @param autor 1-200 carácteres.
     * @param isbn 9-13 carácteres.
     * @param fechaPublicacion que no sea null.
     * @return true si cumple condiciones , false si no las cumple.
     */
    public boolean checkCrearModificarLibro(String titulo, String autor, String isbn,
            java.util.Date fechaPublicacion) {
        boolean todoBien = true;
        if (titulo.equals("") || autor.equals("")
                || fechaPublicacion == null || (isbn.length() < 9)
                || (isbn.length() > 13) || (titulo.length() > 255)
                || (autor.length() > 200)) {
            todoBien = false;
        }
        return todoBien;
    }

    /**
     * Metodo que prueba que se cumpla las siguientes condiciones en
     * VentanaCrearCliente y VentanaModificarCliente:
     *
     * @param dni 9 carácteres.
     * @param nombre 1-100 carácteres.
     * @param apellidos 1-100 carácteres.
     * @param direccion 1-255 carácteres.
     * @param fechaNacimiento Que no sea null.
     * @param telefono 1-15 carácteres.
     * @param email 1-255 carácteres.
     * @return true si se cumple todo, false si no.
     */
    public boolean checkCrearModificarCliente(String dni, String nombre, String apellidos,
            String direccion, java.util.Date fechaNacimiento, String telefono, String email) {
        boolean todoBien = true;
        if ((dni.length() != 9) || nombre.equals("")
                || apellidos.equals("") || direccion.equals("")
                || fechaNacimiento == null || telefono.equals("")
                || email.equals("") || nombre.length() > 100 || apellidos.length() > 100
                || direccion.length() > 255 || telefono.length() > 15
                || email.length() > 255) {
            todoBien = false;
        }
        return todoBien;
    }

    /**
     * Metodo que prueba que se cumpla las siguientes condiciones en
     * VentanaCrearTrabajador y VentanaModificarTrabajador:
     *
     * @param dni 9 carácteres.
     * @param nombre 1-100 carácteres.
     * @param apellidos 1-100 carácteres.
     * @param direccion 1-255 carácteres.
     * @param fechaNacimiento Que no sea null.
     * @param telefono 1-15 carácteres.
     * @param email 1-255 carácteres.
     * @param checkLogin true si se comprueba usuario y password, false no se
     * comprueban
     * @param usuario 5-100 carácteres.
     * @param password 5-15 carácteres.
     * @param rol Que sea mayor que 0.
     * @return true si se cumple todo
     */
    public boolean checkCrearModificarTrabajador(String dni, String nombre, String apellidos,
            String direccion, java.util.Date fechaNacimiento, String telefono, String email,
            boolean checkLogin, String usuario, String password, int rol) {
        boolean todoBien = true;
        if ((dni.length() != 9) || nombre.equals("")
                || apellidos.equals("") || direccion.equals("")
                || fechaNacimiento == null || telefono.equals("")
                || email.equals("") || (rol < 1)
                || nombre.length() > 100 || apellidos.length() > 100
                || direccion.length() > 255 || telefono.length() > 15
                || email.length() > 255) {
            todoBien = false;
        }
        //Si true checkea usuario y password.
        if (checkLogin) {
            if (usuario.length() < 5 || (password.length() < 5)
                    || (password.length() > 15 || usuario.length() > 100)) {
                todoBien = false;
            }
        }
        return todoBien;
    }

    /**
     * Método que prueba que se cumpla las siguientes condiciones en
     * VentanaConfiguración
     * @param nombre 1-100 carácteres.
     * @param direccion 1-255 carácteres.
     * @param maximaCantidadPrestamos Entero de 1 a 100.
     * @param maximaCantidadSanciones Entero de 1 a 100.
     * @param tiempoPrestamos Entero de 1 a 100.
     * @param tiempoPenalizacion Entero de 1 a 100.
     * @return true si se cumple todo
     */
    public boolean checkModificarConfiguracion(String nombre, String direccion,
            String maximaCantidadPrestamos, String maximaCantidadSanciones,
            String tiempoPrestamos, String tiempoPenalizacion) {
        boolean todoBien = true;
        int iMaximaCantidadPrestamos = -1;
        int iMaximaCantidadSanciones = -1;
        int iTiempoPrestamos = -1;
        int iTiempoPenalizacion = -1;
        try {
            iMaximaCantidadPrestamos = Integer.parseInt(maximaCantidadPrestamos);
            iMaximaCantidadSanciones = Integer.parseInt(maximaCantidadSanciones);
            iTiempoPrestamos = Integer.parseInt(tiempoPrestamos);
            iTiempoPenalizacion = Integer.parseInt(tiempoPenalizacion);

        } catch (NumberFormatException e) {
            todoBien = false;
        }

        if (nombre.equals("") || direccion.equals("")
                || (iMaximaCantidadPrestamos < 1) || (iMaximaCantidadPrestamos > 100)
                || (iMaximaCantidadSanciones < 1) || (iMaximaCantidadSanciones > 100)
                || (iTiempoPrestamos < 1) || (iTiempoPrestamos > 100)
                || (iTiempoPenalizacion < 1) || (iTiempoPenalizacion > 100)
                || (nombre.length() > 100) || (direccion.length() > 255)) {
            todoBien = false;
        }
        return todoBien;
    }

    /**
     * Método que llena la tabla de la VentanaPermisos, con los que corresponden
     * a cada rol
     *
     * @param tablaPermisos tabla a rellenar
     * @param conexion Conexión a la BBDD sql.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public void consultarPermisos(javax.swing.JTable tablaPermisos,
            Connection conexion) throws SQLException {
        String sqlConsulta = "SELECT gestionUsuarios, generarInformes, "
                + "gestionColecciones, perdonarSanciones, gestionConfiguracion, "
                + "gestionTrabajadoresPermisos "
                + "FROM RolesFunciones "
                + "WHERE nivelRol < 5";

        PreparedStatement sentenciaConsulta = null;

        ResultSet rsConsulta;

        //Se consulta cada permiso de todos los roles que no son el Administrador.
        sentenciaConsulta = conexion.prepareStatement(sqlConsulta);
        rsConsulta = sentenciaConsulta.executeQuery();

        int fila = 0;
        while (rsConsulta.next() && fila < 4) {
            //Como es una tabla con filas ya hechas, se modifica cada fila y columna
            boolean gestionUsuarios = rsConsulta.getBoolean("gestionUsuarios");
            boolean generarInformes = rsConsulta.getBoolean("generarInformes");
            boolean gestionColecciones = rsConsulta.getBoolean("gestionColecciones");
            boolean perdonarSanciones = rsConsulta.getBoolean("perdonarSanciones");
            boolean gestionConfiguracion = rsConsulta.getBoolean("gestionConfiguracion");
            boolean gestionTrabajadoresPermisos = rsConsulta.getBoolean("gestionTrabajadoresPermisos");

            //La columna 0 no se toca y se introduce los valores a cada fila
            tablaPermisos.setValueAt(gestionUsuarios, fila, 1);
            tablaPermisos.setValueAt(generarInformes, fila, 2);
            tablaPermisos.setValueAt(gestionColecciones, fila, 3);
            tablaPermisos.setValueAt(perdonarSanciones, fila, 4);
            tablaPermisos.setValueAt(gestionConfiguracion, fila, 5);
            tablaPermisos.setValueAt(gestionTrabajadoresPermisos, fila, 6);
            fila++;
        }
        rsConsulta.close();
        sentenciaConsulta.close();

    }

    /**
     * Método que actualiza en la BBDD todos los permisos según el contenido de
     * la tablaPermisos de VentanaPermisos
     *
     * @param tablaPermisos tabla de la que se saca la información
     * @param conexion Conexión a la BBDD sql
     * @return si hace 4 cambios devuelve true, sino false.
     * @throws SQLException Error de conexión BBDD.
     */
    public boolean actualizarPermisos(javax.swing.JTable tablaPermisos,
            Connection conexion) throws SQLException {
        String sqlUpdatePermisos = "UPDATE RolesFunciones SET "
                + "gestionUsuarios = ?, generarInformes = ?, gestionColecciones = ?, "
                + "perdonarSanciones = ?, gestionConfiguracion = ?, gestionTrabajadoresPermisos = ? "
                + "WHERE nivelRol = ?";

        PreparedStatement sentenciaUpdatePermisos = null;
        boolean permisosActualizados = false;
        int iActualizaciones = 0;
        //preparamos la sentencia para actualizar los roles
        sentenciaUpdatePermisos = conexion.prepareStatement(sqlUpdatePermisos);
        for (int i = 0; i < tablaPermisos.getRowCount(); i++) {
            //Cogemos información de la tabla si es true o false cada permiso.
            boolean gestionUsuarios = (boolean) tablaPermisos.getValueAt(i, 1);
            boolean generarInformes = (boolean) tablaPermisos.getValueAt(i, 2);
            boolean gestionColecciones = (boolean) tablaPermisos.getValueAt(i, 3);
            boolean perdonarSanciones = (boolean) tablaPermisos.getValueAt(i, 4);
            boolean gestionConfiguracion = (boolean) tablaPermisos.getValueAt(i, 5);
            boolean gestionTrabajadoresPermisos = (boolean) tablaPermisos.getValueAt(i, 6);
            int nivelRol = i + 1;

            sentenciaUpdatePermisos.setBoolean(1, gestionUsuarios);
            sentenciaUpdatePermisos.setBoolean(2, generarInformes);
            sentenciaUpdatePermisos.setBoolean(3, gestionColecciones);
            sentenciaUpdatePermisos.setBoolean(4, perdonarSanciones);
            sentenciaUpdatePermisos.setBoolean(5, gestionConfiguracion);
            sentenciaUpdatePermisos.setBoolean(6, gestionTrabajadoresPermisos);
            sentenciaUpdatePermisos.setInt(7, nivelRol);
            //Se ejecuta la actualización y se suma para saber cuantas se hacen.
            iActualizaciones = sentenciaUpdatePermisos.executeUpdate() + iActualizaciones;

        }
        sentenciaUpdatePermisos.close();
        //Si se ha hecho cambios devuelve true
        if (iActualizaciones == 4) {
            permisosActualizados = true;
        } else {
            //Si no hace rollBack
            conexion.rollback();
        }

        return permisosActualizados;
    }

    /**
     * Método con consulta la configuración de la BBDD sql e introduce
     * los datos en su cuadro de texto correspondiente.
     * @param nombre JTextField con nombre de la configuración.
     * @param direccion JTextField con dirección.
     * @param cantidadPrestamos JTextField con cantidad de prestamos.
     * @param cantidadSanciones JTextField con cantidad de sanciones.
     * @param tiempoPrestamo JTextField con tiempo de préstamo.
     * @param tiempoSanciones JTextField con tiempo de sanción.
     * @param conexion Conexión a la BBDD sql.
     * @return true si encuentra información. False si no.
     * @throws SQLException 
     */
    public boolean consultarConfiguracion(javax.swing.JTextField nombre,
            javax.swing.JTextField direccion, javax.swing.JTextField cantidadPrestamos,
            javax.swing.JTextField cantidadSanciones, javax.swing.JTextField tiempoPrestamo,
            javax.swing.JTextField tiempoSanciones,
            Connection conexion) throws SQLException {
        String sqlConsultaConfiguracion = "SELECT nombre, direccion, maximaCantidadPrestamos, "
                + "maximaCantidadSanciones, tiempoPrestamos, tiempoPenalizacion "
                + "FROM Configuracion "
                + "WHERE activo = true";

        PreparedStatement sentenciaConsulta = null;
        ResultSet rsConsulta = null;

        boolean configuracionEncontrada = false;
        //preparamos la sentencia para la consulta
        sentenciaConsulta = conexion.prepareStatement(sqlConsultaConfiguracion);

        rsConsulta = sentenciaConsulta.executeQuery();
        if (rsConsulta.next()) {
            nombre.setText(rsConsulta.getString("nombre"));
            direccion.setText(rsConsulta.getString("direccion"));
            cantidadPrestamos.setText(rsConsulta.getInt("maximaCantidadPrestamos") + "");
            cantidadSanciones.setText(rsConsulta.getInt("maximaCantidadSanciones") + "");
            tiempoPrestamo.setText(rsConsulta.getInt("tiempoPrestamos") + "");
            tiempoSanciones.setText(rsConsulta.getInt("tiempoPenalizacion") + "");
            configuracionEncontrada = true;
        }
        rsConsulta.close();
        sentenciaConsulta.close();

        return configuracionEncontrada;
    }

    /**
     * Método que actualiza la configuración de la biblioteca con una sentencia
     * UPDATE.
     * @param nombre nombre de la configuración.
     * @param direccion Dirección de la biblioteca.
     * @param cantidadPrestamos Prestamos simultaneos por usuario.
     * @param cantidadSanciones Sanciones máximas en un usuario.
     * @param tiempoPrestamo Tiempo de los prestamos.
     * @param tiempoSanciones Tiempo de las sanciones.
     * @param conexion Conexión a la BBDD.
     * @return true si actualiza, false si no.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean modificarConfiguracion(String nombre,
            String direccion, String cantidadPrestamos,
            String cantidadSanciones, String tiempoPrestamo,
            String tiempoSanciones,
            Connection conexion) throws SQLException {
        String sqlUpdateConfiguracion = "UPDATE Configuracion SET "
                + "nombre = ?, direccion = ?, maximaCantidadPrestamos = ?, "
                + "maximaCantidadSanciones = ?, tiempoPrestamos = ?, "
                + "tiempoPenalizacion = ? "
                + "WHERE activo = true";

        PreparedStatement sentenciaUpdateConfiguracion = null;
        boolean configuracionActualizada = false;
        int iActualizacion = 0;

        int iMaximaCantidadPrestamos = Integer.parseInt(cantidadPrestamos);
        int iMaximaCantidadSanciones = Integer.parseInt(cantidadSanciones);
        int iTiempoPrestamos = Integer.parseInt(tiempoPrestamo);
        int iTiempoPenalizacion = Integer.parseInt(tiempoSanciones);
        //preparamos la sentencia para actualizar los roles
        sentenciaUpdateConfiguracion = conexion.prepareStatement(sqlUpdateConfiguracion);
        sentenciaUpdateConfiguracion.setString(1, nombre);
        sentenciaUpdateConfiguracion.setString(2, direccion);
        sentenciaUpdateConfiguracion.setInt(3, iMaximaCantidadPrestamos);
        sentenciaUpdateConfiguracion.setInt(4, iMaximaCantidadSanciones);
        sentenciaUpdateConfiguracion.setInt(5, iTiempoPrestamos);
        sentenciaUpdateConfiguracion.setInt(6, iTiempoPenalizacion);
        
        iActualizacion = sentenciaUpdateConfiguracion.executeUpdate();
        sentenciaUpdateConfiguracion.close();
        //Si se ha hecho cambios devuelve true
        if(iActualizacion > 0){
            configuracionActualizada = true;
        }

        return configuracionActualizada;
    }

}

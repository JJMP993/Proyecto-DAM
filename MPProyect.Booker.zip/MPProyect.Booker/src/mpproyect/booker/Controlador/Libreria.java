package mpproyect.booker.Controlador;

import java.sql.*;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import javax.swing.table.DefaultTableModel;

import mpproyect.booker.modelo.Cliente;
import mpproyect.booker.modelo.Libro;
import mpproyect.booker.modelo.Prestamo;
import mpproyect.booker.modelo.Sancion;
import mpproyect.booker.modelo.Trabajador;

/**
 * Clase controladora que contiene los ArrayList libros, clientes, trabajadores,
 * prestamos y sanciones, Esta clase gestiona los prestamos, devoluciones y
 * sanciones en la BBDD con sentencias SQL.
 *
 * @author José Javier Morillas Pérez
 */
public class Libreria {

    /**
     * Nombre de libreria (SIN USO AUN)
     */
    private String nombre;
    
    /**
     * Dirección de la libreria (SIN USO AUN)
     */
    private String direccion;
    
    /**
     * Lista de objetos de tipo Libro, se llena según ciertos criterios.
     */
    private ArrayList<Libro> libros;
    
    /**
     * Lista de objetos de tipo Cliente, se llena según ciertos criterios.
     */
    private ArrayList<Cliente> clientes;
    
    /**
     * Lista de objetos de tipo Trabajador, se llena según ciertos criterios.
     */
    private ArrayList<Trabajador> trabajadores;
    
    /**
     * Lista de objetos de tipo Prestamo, se llena según ciertos criterios.
     */
    private ArrayList<Prestamo> prestamos;
    
    /**
     * Lista de objetos de tipo Sancion, se llena según ciertos criterios.
     */
    private ArrayList<Sancion> sanciones;
    
    /**
     * Maxima cantidad de prestamos por usuario.
     */
    private int prestamosPorUsuario;
    
    /**
     * Tiempo de prestamo.
     */
    private int tiempoPrestamo;
    
    /**
     * Sanciones antes de bloqueo permanente.
     */
    private int maxSancionesPorUsuario;
    
    /**
     * Duración de la sanción
     */
    private int tiempoSancion;

    /**
     * Constructor por defecto de la clase Libreria.
     */
    public Libreria() {
    }

    /**
     * Constructor que inicializa la clase Libreria con una conexión a la base
     * de datos para consultar la configuración. Inicializa los ArrayList
     * Se usa en VentanaPrincipal
     *
     * @param conexion la conexión a la base de datos.
     * @throws SQLException si ocurre un error con la conexión.
     */
    public Libreria(Connection conexion) throws SQLException {
        libros = new ArrayList<Libro>();
        clientes = new ArrayList<Cliente>();
        trabajadores = new ArrayList<Trabajador>();
        prestamos = new ArrayList<Prestamo>();
        sanciones = new ArrayList<Sancion>();
        String sqlConfiguracion = "SELECT maximaCantidadPrestamos, TiempoPrestamos, maximaCantidadSanciones, tiempoPenalizacion "
                + "FROM Configuracion "
                + "WHERE activo = true";
        PreparedStatement sentencia = conexion.prepareStatement(sqlConfiguracion);
        ResultSet rsConfiguracion = sentencia.executeQuery();
        if (rsConfiguracion.next()) {
            this.prestamosPorUsuario = rsConfiguracion.getInt("maximaCantidadPrestamos");
            this.tiempoPrestamo = rsConfiguracion.getInt("TiempoPrestamos");
            this.maxSancionesPorUsuario = rsConfiguracion.getInt("maximaCantidadSanciones");
            this.tiempoSancion = rsConfiguracion.getInt("tiempoPenalizacion");
        }
        rsConfiguracion.close();
        sentencia.close();
        conexion.close();

    }

    public Libreria(String nombre, String direccion, ArrayList<Libro> libros, ArrayList<Cliente> clientes,
            ArrayList<Trabajador> trabajadores, ArrayList<Prestamo> prestamos, ArrayList<Sancion> sanciones,
            int prestamosPorUsuario, int tiempoPrestamo, int maxSancionesPorUsuario, int tiempoSancion) {
        this.nombre = nombre;
        this.direccion = direccion;
        this.libros = libros;
        this.clientes = clientes;
        this.trabajadores = trabajadores;
        this.prestamos = prestamos;
        this.sanciones = sanciones;
        this.prestamosPorUsuario = prestamosPorUsuario;
        this.tiempoPrestamo = tiempoPrestamo;
        this.maxSancionesPorUsuario = maxSancionesPorUsuario;
        this.tiempoSancion = tiempoSancion;
    }

    /**
     * Obtiene el nombre de la librería.
     *
     * @return el nombre de la librería.
     */
    public String getNombre() {
        return nombre;
    }

    /**
     * Establece el nombre de la librería.
     *
     * @param nombre el nombre que se establecerá.
     */
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    /**
     * Obtiene la dirección de la librería.
     *
     * @return la dirección de la librería.
     */
    public String getDireccion() {
        return direccion;
    }

    /**
     * Establece la dirección de la librería.
     *
     * @param direccion la dirección que se establecerá.
     */
    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    /**
     * Obtiene la lista de libros.
     *
     * @return la lista de libros de la librería.
     */
    public ArrayList<Libro> getLibros() {
        return libros;
    }

    /**
     * Establece la lista de libros.
     *
     * @param libros la lista de libros que se establecerá.
     */
    public void setLibros(ArrayList<Libro> libros) {
        this.libros = libros;
    }

    /**
     * Obtiene la lista de clientes.
     *
     * @return la lista de clientes de la librería.
     */
    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    /**
     * Establece la lista de clientes.
     *
     * @param clientes la lista de clientes que se establecerá.
     */
    public void setClientes(ArrayList<Cliente> clientes) {
        this.clientes = clientes;
    }

    /**
     * Obtiene la lista de trabajadores.
     *
     * @return la lista de trabajadores de la librería.
     */
    public ArrayList<Trabajador> getTrabajadores() {
        return trabajadores;
    }

    /**
     * Establece la lista de trabajadores.
     *
     * @param trabajadores la lista de trabajadores que se establecerá.
     */
    public void setTrabajadores(ArrayList<Trabajador> trabajadores) {
        this.trabajadores = trabajadores;
    }

    /**
     * Obtiene la lista de préstamos.
     *
     * @return la lista de préstamos de la librería.
     */
    public ArrayList<Prestamo> getPrestamos() {
        return prestamos;
    }

    /**
     * Establece la lista de préstamos.
     *
     * @param prestamos la lista de préstamos que se establecerá.
     */
    public void setPrestamos(ArrayList<Prestamo> prestamos) {
        this.prestamos = prestamos;
    }

    /**
     * Obtiene la lista de sanciones.
     *
     * @return la lista de sanciones de la librería.
     */
    public ArrayList<Sancion> getSanciones() {
        return sanciones;
    }

    /**
     * Establece la lista de sanciones.
     *
     * @param sanciones la lista de sanciones que se establecerá.
     */
    public void setSanciones(ArrayList<Sancion> sanciones) {
        this.sanciones = sanciones;
    }


    public int getPrestamosPorUsuario() {
        return prestamosPorUsuario;
    }

    /**
     * Establece el número máximo de préstamos por usuario.
     *
     * @param prestamosPorUsuario el número máximo de préstamos que se
     * permitirá.
     */
    public void setPrestamosPorUsuario(int prestamosPorUsuario) {
        this.prestamosPorUsuario = prestamosPorUsuario;
    }

    /**
     * Obtiene el tiempo de préstamo.
     *
     * @return el tiempo máximo de préstamo.
     */
    public int getTiempoPrestamo() {
        return tiempoPrestamo;
    }

    /**
     * Establece el tiempo de préstamo.
     *
     * @param tiempoPrestamo el tiempo máximo de préstamo que se permitirá.
     */
    public void setTiempoPrestamo(int tiempoPrestamo) {
        this.tiempoPrestamo = tiempoPrestamo;
    }

    /**
     * Obtiene el número máximo de sanciones por usuario.
     *
     * @return el número máximo de sanciones por usuario.
     */
    public int getMaxSancionesPorUsuario() {
        return maxSancionesPorUsuario;
    }

    /**
     * Establece el número máximo de sanciones por usuario.
     *
     * @param maxSancionesPorUsuario el número máximo de sanciones que se
     * permitirá.
     */
    public void setMaxSancionesPorUsuario(int maxSancionesPorUsuario) {
        this.maxSancionesPorUsuario = maxSancionesPorUsuario;
    }

    /**
     * Obtiene el tiempo de sanción.
     *
     * @return el tiempo máximo de sanción.
     */
    public int getTiempoSancion() {
        return tiempoSancion;
    }

    /**
     * Establece el tiempo de sanción.
     *
     * @param tiempoSancion el tiempo máximo de sanción que se permitirá.
     */
    public void setTiempoSancion(int tiempoSancion) {
        this.tiempoSancion = tiempoSancion;
    }

    /**
     * Metodo que sirve para preparar la parte del WHERE IN() para asi hacer
     * busquedas multiples de forma dinámica con las ids del ArrayList.
     *
     * @param lista lista de ids que quieres buscar en la sentencia.
     * @return String con ultima parte de la sentencia sql que contiene los id a
     * buscar.
     */
    private String generarStringBusqueda(ArrayList<Integer> lista) {
        String sBusqueda = "";
        for (int i = 0; i < lista.size(); i++) {
            if (i == 0) {
                sBusqueda = sBusqueda + lista.get(i);
            } else {
                sBusqueda = sBusqueda + ", " + lista.get(i);
            }
        }
        sBusqueda = sBusqueda + ");";

        return sBusqueda;
    }
    
    
    // VentanaPrincipal
    
    /**
     * Metodo que recorre todas las sanciones que haya pasado su tiempo de
     * finalizar, si el usuario no tiene más sanciones le pone el estado
     * estaPenalizado a false, si hay alguna excepción hace rollback de forma
     * preventiva para mantener integridad de datos.
     *
     * @param conexion conexión a la BBDD
     */
    public void finalizarSancionesCumplidas(Connection conexion) {
        //se preparan las sentencias
        String sqlSelectSanciones = "SELECT idCliente, idSancion "
                + "FROM Sancion "
                + "WHERE diaFinSancion <= CURDATE() AND estaActivo = true";
        String sqldesactivarSancion = "UPDATE Sancion "
                + "SET estaActivo = false "
                + "WHERE idSancion = ?";
        String sqlRecuentoSanciones = "SELECT COUNT(*) "
                + "FROM Sancion "
                + "WHERE idCliente = ? AND estaActivo = true AND diaFinSancion > CURDATE()";
        String sqldesbloquearCliente = "UPDATE Cliente "
                + "SET estaPenalizado = false "
                + "WHERE idUsuario = ?";
        PreparedStatement sancionesActivas = null;
        try {
            sancionesActivas = conexion.prepareStatement(sqlSelectSanciones);

            PreparedStatement recuentoSanciones = conexion.prepareStatement(sqlRecuentoSanciones);

            PreparedStatement desactivarSancion = conexion.prepareStatement(sqldesactivarSancion);

            PreparedStatement desbloquearCliente = conexion.prepareStatement(sqldesbloquearCliente);

            ResultSet rsSanciones = sancionesActivas.executeQuery();
            ResultSet rsRecuento = null;

            //Primero cogemos idCliente e idSancion de las sanciones que acaban
            while (rsSanciones.next()) {
                int idCliente = rsSanciones.getInt("idCliente");
                int idSancion = rsSanciones.getInt("idSancion");

                //Desactivamos sanción
                desactivarSancion.setInt(1, idSancion);
                desactivarSancion.executeUpdate();

                //Comprobamos cuantas sanciones activas tiene el cliente
                recuentoSanciones.setInt(1, idCliente);
                rsRecuento = recuentoSanciones.executeQuery();
                if (rsRecuento.next()) {
                    int iSancionesActivas = rsRecuento.getInt(1);
                    //Si tiene 0 sanciones se le quita la penalización
                    if (iSancionesActivas == 0) {
                        desbloquearCliente.setInt(1, idCliente);
                        desbloquearCliente.executeUpdate();
                    }
                }
            }
            rsSanciones.close();
            if (rsRecuento != null) {
                rsRecuento.close();
            }
            sancionesActivas.close();
            recuentoSanciones.close();
            desbloquearCliente.close();
            desactivarSancion.close();
        } catch (SQLException ex) {
            try {
                conexion.rollback();
            } catch (SQLException ex1) {
            }
        } finally {
            if (conexion != null) {
                try {
                    conexion.close();
                } catch (SQLException ex) {
                }
            }
        }

    }

    /**
     * Metodo para el inicio de la VentanaPrincipal que busca si hay prestamos
     * pasados y cambia el atributo estaPenalizado a true de esos usuarios que
     * tienen prestamos pasados.
     *
     * @param conexion conexión a la base de datos.
     * @throws SQLException fallo en la sentencia.
     */
    public void prohibirPrestamos(Connection conexion) throws SQLException {
        //se prepara las sentencias
        String sqlPrestamos = "SELECT idCliente FROM Prestamo "
                + "WHERE finPrestamo < CURDATE()";
        String sqlProhibir = "UPDATE Cliente SET estaPenalizado = true "
                + "WHERE idUsuario IN (";
        boolean hayPrestamos = false;
        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;
        ArrayList<Integer> usuariosBuscar = new ArrayList<Integer>();

        sentencia = conexion.prepareStatement(sqlPrestamos);
        resultadoBusqueda = sentencia.executeQuery();
        //Comprobamos si hay prestamos caducados
        while (resultadoBusqueda.next()) {
            hayPrestamos = true;
            int idCliente = resultadoBusqueda.getInt("idCliente");
            //Guardamos los id de los que tienen prestamos caducados
            usuariosBuscar.add(idCliente);
        }
        resultadoBusqueda.close();
        sentencia.close();

        if (hayPrestamos) {
            //primero eliminamos duplicados del ArrayList de clientes
            Set<Integer> clientesSinDup = new HashSet<Integer>(usuariosBuscar);
            ArrayList<Integer> clientes = new ArrayList<Integer>(clientesSinDup);

            //completamos la sentencia sql para prohibir prestamos
            sqlProhibir = sqlProhibir + generarStringBusqueda(clientes);

            sentencia = conexion.prepareStatement(sqlProhibir);
            sentencia.executeUpdate();
            sentencia.close();
        }
        conexion.close();
    }

    /**
     * Metodo que llena el ArrayList de prestamos con los que sobrepasan la
     * fecha de devolución, si hay prestamos pasados también llena los ArrayList
     * libros y clientes con los usuarios y libros relacionados con esos
     * prestamos. Solo recoge la información necesaria para la ventana
     * principal.
     *
     * @param conexion Connection instancia de conexion sql.
     * @throws SQLException error en la busqueda.
     * @return booleano que indica si hay prestamos pasados
     */
    public boolean consultarPrestamosPasados(Connection conexion) throws SQLException {
        //se prepara las sentencias
        String sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente,"
                + " finPrestamo FROM Prestamo "
                + "WHERE finPrestamo < CURDATE()";
        //sentencias incompletas para clientes y libros
        String sqlClientes = "SELECT idUsuario, nombre, apellidos"
                + " FROM Cliente WHERE idUsuario IN (";
        String sqlLibros = "SELECT idLibro, titulo FROM Libro WHERE idLibro IN (";

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;
        //Sirve para hacer o no busqueda de clientes y libros
        boolean hayPrestamos = false;
        //ArrayList de id de libros y clientes que se relacionan con los prestamos
        ArrayList<Integer> usuariosBuscar = new ArrayList<Integer>();
        ArrayList<Integer> librosBuscar = new ArrayList<Integer>();

        //necesitamos ArrayList vacios para luego usarlos
        this.prestamos.clear();
        this.clientes.clear();
        this.libros.clear();

        //Busqueda y llenado de ArrayList prestamos
        sentencia = conexion.prepareStatement(sqlPrestamos);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayPrestamos = true;
            Prestamo prestamo = new Prestamo();
            int idPrestamo = resultadoBusqueda.getInt("idPrestamo");
            int idLibro = resultadoBusqueda.getInt("idLibro");
            int idCliente = resultadoBusqueda.getInt("idCliente");
            Date finPrestamo = resultadoBusqueda.getDate("finPrestamo");

            //identificación de que clientes y libros buscar
            usuariosBuscar.add(idCliente);
            librosBuscar.add(idLibro);

            //Se introduce el prestamo en el ArrayList prestamos.
            prestamo.setId(idPrestamo);
            prestamo.setIdLibro(idLibro);
            prestamo.setIdCliente(idCliente);
            prestamo.setFechaLimite(finPrestamo);
            this.prestamos.add(prestamo);
        }
        resultadoBusqueda.close();
        sentencia.close();

        if (hayPrestamos) {
            //primero eliminamos duplicados del ArrayList de clientes
            Set<Integer> clientesSinDup = new HashSet<Integer>(usuariosBuscar);
            ArrayList<Integer> clientes = new ArrayList<Integer>(clientesSinDup);

            //Creamos las sentencias completas para cliente y libro
            sqlClientes = sqlClientes + generarStringBusqueda(clientes);
            sqlLibros = sqlLibros + generarStringBusqueda(librosBuscar);

            //primero buscamos clientes
            sentencia = conexion.prepareStatement(sqlClientes);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Cliente cliente = new Cliente();
                int idCliente = resultadoBusqueda.getInt("idUsuario");
                String nombre = resultadoBusqueda.getString("nombre");
                String apellidos = resultadoBusqueda.getString("apellidos");

                cliente.setId(idCliente);
                cliente.setNombre(nombre);
                cliente.setApellidos(apellidos);
                this.clientes.add(cliente);
            }
            resultadoBusqueda.close();
            sentencia.close();

            //Busqueda de Libros
            sentencia = conexion.prepareStatement(sqlLibros);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Libro libro = new Libro();
                int idLibro = resultadoBusqueda.getInt("idLibro");
                String titulo = resultadoBusqueda.getString("titulo");

                libro.setId(idLibro);
                libro.setTitulo(titulo);
                this.libros.add(libro);
            }
            resultadoBusqueda.close();
            sentencia.close();
        }
        return hayPrestamos;
    }

    /**
     * Metodo que usa los ArrayList prestamos, clientes y libros para llenar la
     * tabla con los datos correspondientes
     *
     * @param tabla tabla a modificar
     */
    public void llenarTablaPrincipal(javax.swing.JTable tabla) {
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        SimpleDateFormat formateoFecha = new SimpleDateFormat("dd-MM-yyyy");

        //Despues de recuperar el modelo de la tabla borramos el contenido de esta.
        modelo.setRowCount(0);

        //Buscamos la correspondencia de cada prestamo en clientes y libros
        for (Prestamo prestamo : this.prestamos) {
            String nombreCliente = "";
            String titulo = "";
            String fFinPrestamo = formateoFecha.format(prestamo.getFechaLimite());

            for (Cliente cliente : this.clientes) {
                if (cliente.getId() == prestamo.getIdCliente()) {
                    nombreCliente = cliente.getNombre() + " " + cliente.getApellidos();
                    break;
                }
            }

            for (Libro libro : this.libros) {
                if (libro.getId() == prestamo.getIdLibro()) {
                    titulo = libro.getTitulo();
                    break;
                }
            }
            //Se debe meter los datos recuperados en el orden correcto
            Object[] row = {
                prestamo.getIdCliente(),
                nombreCliente,
                prestamo.getIdLibro(),
                titulo,
                fFinPrestamo,
                prestamo.getId()};
            modelo.addRow(row);

        }
    }

    //VentanaPrestamos
    /**
     * Metodo que llena los array libros y clientes para VentanaPrestamos, solo
     * coge los clientes que no estan bloqueados ni penalizados y los libros que
     * son prestables y no estan en prestamo.
     *
     * @param conexion conexion a la base de datos
     * @throws SQLException Error de conexión a la BBDD.
     */
    public void consultarVentanaPrestamos(Connection conexion) throws SQLException {

        //Preparamos sentencias
        String sqlClientes = "SELECT idUsuario, dni, nombre, apellidos, numPrestamosActivos "
                + "FROM Cliente "
                + "WHERE estaPenalizado = false AND estaPenalizadoPerm = false";
        String sqlLibros = "SELECT idLibro, titulo, autor "
                + "FROM Libro "
                + "WHERE esPrestable = true AND enPrestamo = false";

        //Vaciamos ArrayList
        this.clientes.clear();
        this.libros.clear();

        PreparedStatement sentenciaClientes = conexion.prepareStatement(sqlClientes);
        PreparedStatement sentenciaLibros = conexion.prepareStatement(sqlLibros);

        //Recuperamos todos los clientes no penalizados
        ResultSet rsClientes = sentenciaClientes.executeQuery();
        while (rsClientes.next()) {
            int id = rsClientes.getInt("idUsuario");
            String dni = rsClientes.getString("dni");
            String nombre = rsClientes.getString("nombre");
            String apellido = rsClientes.getString("apellidos");
            int prestamosActivos = rsClientes.getInt("numPrestamosActivos");
            Cliente cliente = new Cliente();
            cliente.setId(id);
            cliente.setDni(dni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellido);
            cliente.setPrestamosActivos(prestamosActivos);
            this.clientes.add(cliente);
        }
        rsClientes.close();
        sentenciaClientes.close();

        //Recuperamos todos los libros prestables y que no estan en prestamo
        ResultSet rsLibros = sentenciaLibros.executeQuery();
        while (rsLibros.next()) {
            int id = rsLibros.getInt("idLibro");
            String titulo = rsLibros.getString("titulo");
            String autor = rsLibros.getString("autor");

            Libro libro = new Libro();
            libro.setId(id);
            libro.setTitulo(titulo);
            libro.setAutor(autor);

            this.libros.add(libro);
        }
        rsLibros.close();
        sentenciaLibros.close();
    }

    /**
     * .
     * Llena la tabla de clientes de la ventanaPrestamos con el array clientes
     * de esta misma clase.
     *
     * @param tablaClientes tabla a modificar.
     */
    public void llenarTablaPrestamosClientes(javax.swing.JTable tablaClientes) {
        DefaultTableModel modeloClientes = (DefaultTableModel) tablaClientes.getModel();

        modeloClientes.setRowCount(0);

        //Cogemos del array clientes los datos necesarios
        for (Cliente cliente : this.clientes) {
            int idCliente = cliente.getId();
            String dniCliente = cliente.getDni();
            String nombreCompleto = cliente.getNombre() + " "
                    + cliente.getApellidos();
            boolean posible = false;
            if (cliente.getPrestamosActivos() < this.prestamosPorUsuario) {
                posible = true;
            }
            //Introducimos datos en el orden correcto
            Object[] fila = {idCliente, dniCliente, nombreCompleto, posible};
            modeloClientes.addRow(fila);
        }

    }

    /**
     * .
     * Llena la tabla de Libros de la ventanaPrestamos con el array Libros de
     * esta misma clase.
     *
     * @param tablaLibros tabla a modificar.
     */
    public void llenarTablaPrestamosLibros(javax.swing.JTable tablaLibros) {
        DefaultTableModel modeloLibros = (DefaultTableModel) tablaLibros.getModel();

        modeloLibros.setRowCount(0);

        //Recogemos información de cada libro prestable
        for (Libro libro : this.libros) {
            int idLibro = libro.getId();
            String titulo = libro.getTitulo();
            String autor = libro.getAutor();

            //Creamos la fila con los datos
            Object[] fila = {idLibro, titulo, autor};
            modeloLibros.addRow(fila);
        }
    }

    /**
     * Metodo que busca por dni los clientes y los introduce en el array, si no
     * pones dni hace una busqueda sin dni. Esta busqueda es para la
     * VentanaPrestamos
     *
     * @param conexion conexion a la BBDD
     * @param dni DNI de la persona que buscas
     * @throws SQLException
     */
    public void buscarClientesDni(Connection conexion, String dni) throws SQLException {
        boolean busquedaGeneral = false;
        //Se elige busqueda concreta o busqueda general si no se escribe dni
        String sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, numPrestamosActivos "
                + "FROM Cliente "
                + "WHERE estaPenalizado = false "
                + "AND estaPenalizadoPerm = false "
                + "AND dni=?";
        if (dni.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, numPrestamosActivos "
                    + "FROM Cliente "
                    + "WHERE estaPenalizado = false "
                    + "AND estaPenalizadoPerm = false";
            busquedaGeneral = true;
        }
        this.clientes.clear();
        PreparedStatement sentencia = conexion.prepareStatement(sqlCliente);

        //Solo se asigna si se busca
        if (!busquedaGeneral) {
            sentencia.setString(1, dni);
        }

        ResultSet rsCliente = sentencia.executeQuery();
        //Se rellena el ArrayList clientes con los datos necesarios
        while (rsCliente.next()) {
            int id = rsCliente.getInt("idUsuario");
            String sDni = rsCliente.getString("dni");
            String nombre = rsCliente.getString("nombre");
            String apellido = rsCliente.getString("apellidos");
            int prestamosActivos = rsCliente.getInt("numPrestamosActivos");
            Cliente cliente = new Cliente();
            cliente.setId(id);
            cliente.setDni(sDni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellido);
            cliente.setPrestamosActivos(prestamosActivos);
            this.clientes.add(cliente);

        }
        rsCliente.close();
        sentencia.close();
    }

    /**
     * Metodo que busca por id los clientes y los introduce en el array, si no
     * pones id hace una busqueda sin id. Esta busqueda es para la
     * VentanaPrestamos
     *
     * @param conexion Conexión a la BBDD
     * @param id id del cliente
     * @throws SQLException
     */
    public void buscarClientesId(Connection conexion, String id) throws SQLException {
        boolean busquedaGeneral = false;
        //Se elige busqueda concreta o busqueda general si no se escribe ID.
        String sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, numPrestamosActivos "
                + "FROM Cliente "
                + "WHERE estaPenalizado = false "
                + "AND estaPenalizadoPerm = false "
                + "AND idUsuario=?";
        if (id.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, numPrestamosActivos "
                    + "FROM Cliente "
                    + "WHERE estaPenalizado = false "
                    + "AND estaPenalizadoPerm = false";
            busquedaGeneral = true;
        }
        this.clientes.clear();
        PreparedStatement sentencia = conexion.prepareStatement(sqlCliente);

        //Solo se asigna si se busca
        if (!busquedaGeneral) {
            int iId = Integer.parseInt(id);
            sentencia.setInt(1, iId);
        }
        ResultSet rsCliente = sentencia.executeQuery();
        while (rsCliente.next()) {
            //Se rellena el ArrayList clientes con los datos necesarios
            int iId = rsCliente.getInt("idUsuario");
            String Dni = rsCliente.getString("dni");
            String nombre = rsCliente.getString("nombre");
            String apellido = rsCliente.getString("apellidos");
            int prestamosActivos = rsCliente.getInt("numPrestamosActivos");
            Cliente cliente = new Cliente();
            cliente.setId(iId);
            cliente.setDni(Dni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellido);
            cliente.setPrestamosActivos(prestamosActivos);
            this.clientes.add(cliente);
        }
        rsCliente.close();
        sentencia.close();

    }

    /**
     * Metodo que busca por titulo los libros y los introduce en el array, si no
     * pones titulo hace una busqueda sin titulo. Esta busqueda es para la
     * VentanaPrestamos
     *
     * @param conexion Conexión a la BBDD.
     * @param titulo titulo del libro
     * @throws SQLException Error de conexión con la BBDD
     */
    public void buscarLibroTitulo(Connection conexion, String titulo) throws SQLException {
        boolean busquedaGeneral = false;
        //Se elige busqueda concreta o busqueda general si no se escribe título.
        String sqlLibros = "SELECT idLibro, titulo, autor "
                + "FROM Libro "
                + "WHERE esPrestable = true "
                + "AND enPrestamo = false "
                + "AND titulo LIKE ?";
        if (titulo.equals("")) {
            sqlLibros = "SELECT idLibro, titulo, autor "
                    + "FROM Libro "
                    + "WHERE esPrestable = true "
                    + "AND enPrestamo = false";
            busquedaGeneral = true;
        }
        this.libros.clear();

        PreparedStatement sentencia = conexion.prepareStatement(sqlLibros);
        //Solo se asigna si se busca
        if (!busquedaGeneral) {
            sentencia.setString(1, "%" + titulo.trim() + "%");
        }

        ResultSet rsLibros = sentencia.executeQuery();
        while (rsLibros.next()) {
            //Se rellena el ArrayList libros con los datos necesarios
            int id = rsLibros.getInt("idLibro");
            String sTitulo = rsLibros.getString("titulo");
            String autor = rsLibros.getString("autor");

            Libro libro = new Libro();
            libro.setId(id);
            libro.setTitulo(sTitulo);
            libro.setAutor(autor);

            this.libros.add(libro);
        }
        rsLibros.close();
        sentencia.close();

    }

    /**
     * Metodo que busca por id los libros y los introduce en el array, si no
     * pones ID hace una busqueda sin ID. Esta busqueda es para la
     * VentanaPrestamos
     *
     * @param conexion Conexión a la BBDD.
     * @param id idLibro
     * @throws SQLException Error de conexión con la BBDD
     */
    public void buscarLibroId(Connection conexion, String id) throws SQLException {
        boolean busquedaGeneral = false;
        //Se elige busqueda concreta o busqueda general si no se escribe ID.
        String sqlLibros = "SELECT idLibro, titulo, autor "
                + "FROM Libro "
                + "WHERE esPrestable = true "
                + "AND enPrestamo = false "
                + "AND idLibro=?";
        if (id.equals("")) {
            sqlLibros = "SELECT idLibro, titulo, autor "
                    + "FROM Libro "
                    + "WHERE esPrestable = true "
                    + "AND enPrestamo = false";
            busquedaGeneral = true;
        }
        this.libros.clear();

        PreparedStatement sentencia = conexion.prepareStatement(sqlLibros);
        //Solo se asigna si se busca
        if (!busquedaGeneral) {
            int iId = Integer.parseInt(id);
            sentencia.setInt(1, iId);
        }

        ResultSet rsLibros = sentencia.executeQuery();
        while (rsLibros.next()) {
            //Se rellena el ArrayList libros con los datos necesarios
            int iId = rsLibros.getInt("idLibro");
            String titulo = rsLibros.getString("titulo");
            String autor = rsLibros.getString("autor");

            Libro libro = new Libro();
            libro.setId(iId);
            libro.setTitulo(titulo);
            libro.setAutor(autor);

            this.libros.add(libro);
        }
        rsLibros.close();
        sentencia.close();

    }

    /**
     * Metodo que lleva a cabo un prestamo a traves de una insercion en la bbdd
     * de una instancia de prestamo, modifica el numPrestamosActivos de la
     * instancia Cliente del cliente que lo pide y cambia el estado enPrestamo a
     * true; Si no lo consigue hace rollback.
     *
     * @param idUsuario ID del cliente que pide el libro.
     * @param idLibro ID del libro que se presta.
     * @param conexion Conexion a la base de datos
     * @return true si hace la inserción y false si no la hace.
     */
    public boolean prestarLibro(int idUsuario, int idLibro, Connection conexion) {
        boolean libroPrestado = false;
        String sqlCantidadPrestamos = "SELECT COUNT(*) FROM Prestamo WHERE idCliente = ?";
        String sqlInsert = "INSERT INTO Prestamo (idLibro, idCliente, FinPrestamo) "
                + "VALUES (?, ?, ?)";
        String sqlCliente = "UPDATE Cliente "
                + "SET numPrestamosActivos = numPrestamosActivos + 1 "
                + "WHERE idUsuario = " + idUsuario;
        String sqlLibro = "UPDATE Libro SET enPrestamo = true "
                + "WHERE enPrestamo = false AND idLibro = " + idLibro;

        PreparedStatement sentenciaCantidadPrestamos = null;
        PreparedStatement sentenciaPrestamo = null;
        PreparedStatement sentenciaCliente = null;
        PreparedStatement sentenciaLibro = null;

        ResultSet rsCantidadPrestamos = null;
        int iFilasAfectadas = 0;
        int iPrestamosActivos = this.prestamosPorUsuario;
        try {
            sentenciaCantidadPrestamos = conexion.prepareStatement(sqlCantidadPrestamos);
            sentenciaCantidadPrestamos.setInt(1, idUsuario);
            //Primero miramos cuantos prestamos tiene el cliente
            rsCantidadPrestamos = sentenciaCantidadPrestamos.executeQuery();
            if (rsCantidadPrestamos.next()) {
                iPrestamosActivos = rsCantidadPrestamos.getInt(1);
            }
            rsCantidadPrestamos.close();
            sentenciaCantidadPrestamos.close();
            //si tiene menos prestamos de los permitidos pues puede pedir
            if ((iPrestamosActivos < this.prestamosPorUsuario) && (idUsuario > 0)
                    && (idLibro > 0)) {
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.DAY_OF_MONTH, this.tiempoPrestamo);
                Date finPrestamo = new Date(calendar.getTimeInMillis());

                sentenciaPrestamo = conexion.prepareStatement(sqlInsert);
                sentenciaPrestamo.setInt(1, idLibro);
                sentenciaPrestamo.setInt(2, idUsuario);
                sentenciaPrestamo.setDate(3, finPrestamo);

                //Se da de alta un prestamo
                iFilasAfectadas = sentenciaPrestamo.executeUpdate();
                sentenciaPrestamo.close();
                if (iFilasAfectadas > 0) {
                    //Se actualiza la cantidad de prestamos simultaneos en el cliente.
                    sentenciaCliente = conexion.prepareStatement(sqlCliente);
                    int iFilasAfectadas2 = sentenciaCliente.executeUpdate();

                    //Se pone en estado enPrestamo al libro
                    sentenciaLibro = conexion.prepareStatement(sqlLibro);
                    int iFilasAfectadas3 = sentenciaLibro.executeUpdate();

                    sentenciaCliente.close();
                    sentenciaLibro.close();

                    if ((iFilasAfectadas2 > 0) && (iFilasAfectadas3 > 0)) {
                        libroPrestado = true;
                    }
                }
                //si no se llega hasta el final se hace rollback.
                if (!libroPrestado) {
                    conexion.rollback();
                }

            }
        } catch (SQLException ex) {
            try {
                libroPrestado = false;
                conexion.rollback();
            } catch (SQLException ex1) {
            } finally {
                try {
                    conexion.close();
                } catch (SQLException ex1) {
                }
            }
        }
        return libroPrestado;
    }

    // VentanaDevoluciones
    /**
     * Metodo que llena el ArrayList de prestamos pendientes, si hay prestamos
     * pendientes también llena los ArrayList libros y clientes con los usuarios
     * y libros relacionados con esos prestamos.
     *
     * @param conexion Conexión a la BBDD
     * @return true si encuentra devoluciones false si no hay
     * @throws SQLException
     */
    public boolean consultarDevolucionesPendientes(Connection conexion) throws SQLException {
        //se prepara las sentencias
        String sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente,"
                + " finPrestamo FROM Prestamo ";
        //sentencias incompletas para clientes y libros
        String sqlClientes = "SELECT idUsuario, dni"
                + " FROM Cliente WHERE idUsuario IN (";
        String sqlLibros = "SELECT idLibro, titulo FROM Libro WHERE idLibro IN (";

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;
        //Sirve para hacer o no busqueda de clientes y libros
        boolean hayPrestamos = false;
        //ArrayList de id de libros y clientes que se relacionan con los prestamos
        ArrayList<Integer> usuariosBuscar = new ArrayList<Integer>();
        ArrayList<Integer> librosBuscar = new ArrayList<Integer>();

        //necesitamos ArrayList vacios para luego usarlos
        this.prestamos.clear();
        this.clientes.clear();
        this.libros.clear();

        //Busqueda y llenado de ArrayList prestamos
        sentencia = conexion.prepareStatement(sqlPrestamos);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayPrestamos = true; //Se hace busqueda de libros y clientes
            Prestamo prestamo = new Prestamo();
            int idPrestamo = resultadoBusqueda.getInt("idPrestamo");
            int idLibro = resultadoBusqueda.getInt("idLibro");
            int idCliente = resultadoBusqueda.getInt("idCliente");
            Date finPrestamo = resultadoBusqueda.getDate("finPrestamo");

            //identificación de que clientes y libros buscar
            usuariosBuscar.add(idCliente);
            librosBuscar.add(idLibro);

            //ponemos los atributos y lo guardamos en el array
            prestamo.setId(idPrestamo);
            prestamo.setIdLibro(idLibro);
            prestamo.setIdCliente(idCliente);
            prestamo.setFechaLimite(finPrestamo);
            this.prestamos.add(prestamo);
        }
        resultadoBusqueda.close();
        sentencia.close();

        if (hayPrestamos) {
            //primero eliminamos duplicados del ArrayList de clientes
            Set<Integer> clientesSinDup = new HashSet<Integer>(usuariosBuscar);
            ArrayList<Integer> clientes = new ArrayList<Integer>(clientesSinDup);

            //Creamos las sentencias completas para cliente y libro
            sqlClientes = sqlClientes + generarStringBusqueda(clientes);
            sqlLibros = sqlLibros + generarStringBusqueda(librosBuscar);

            //primero buscamos clientes
            sentencia = conexion.prepareStatement(sqlClientes);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Cliente cliente = new Cliente();
                int idCliente = resultadoBusqueda.getInt("idUsuario");
                String dni = resultadoBusqueda.getString("dni");

                //ponemos los atributos y lo guardamos en el array
                cliente.setId(idCliente);
                cliente.setDni(dni);
                this.clientes.add(cliente);
            }
            resultadoBusqueda.close();
            sentencia.close();

            //Busqueda de Libros
            sentencia = conexion.prepareStatement(sqlLibros);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Libro libro = new Libro();
                int idLibro = resultadoBusqueda.getInt("idLibro");
                String titulo = resultadoBusqueda.getString("titulo");

                //ponemos los atributos y lo guardamos en el array
                libro.setId(idLibro);
                libro.setTitulo(titulo);
                this.libros.add(libro);
            }
            resultadoBusqueda.close();
            sentencia.close();
        }
        return hayPrestamos;
    }

    /**
     * Metodo sobrecargado que llena el ArrayList de prestamos pendientes, si
     * hay prestamos pendientes también llena los ArrayList libros y clientes
     * con los usuarios y libros relacionados con esos prestamos; El metodo
     * tiene un string que Cambia el metodo de busqueda y busca segun el Dni o
     * id de usuario, y por id de prestamo y id de libro.
     *
     * @param conexion Conexión a la BBDD
     * @param tipoBusqueda String "id", "dni", "idlibro" o "idprestamo"
     * @param busqueda String que contiene el dni, id, idLibro o idPrestamo
     * @return booleano true si hay prestamos false si no hay prestamos.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean consultarDevolucionesPendientes(Connection conexion, String tipoBusqueda,
            String busqueda) throws SQLException {
        //se prepara las sentencias
        String sqlPrestamos = "";
        //if que identifica que tipo de busqueda sera en cuanto a prestamos
        if (tipoBusqueda.equals("id") && !busqueda.equals("")) {
            sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente, "
                    + "finPrestamo FROM Prestamo "
                    + "WHERE idCliente = " + busqueda;
        } else if (tipoBusqueda.equals("dni") && !busqueda.equals("")) {
            String sqlDni = "SELECT idUsuario "
                    + "FROM Cliente "
                    + "WHERE dni = " + busqueda;

            // Se consulta idUsuario de la tabla Cliente usando el DNI
            PreparedStatement sentenciaDni = conexion.prepareStatement(sqlDni);
            ResultSet rsDni = sentenciaDni.executeQuery();
            if (rsDni.next()) {
                int id = rsDni.getInt(1);
                sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente, "
                        + "finPrestamo FROM Prestamo "
                        + "WHERE idCliente = " + id;
            } else {
                sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente,"
                        + " finPrestamo FROM Prestamo ";
            }
            rsDni.close();
            sentenciaDni.close();
        } else if (tipoBusqueda.equals("idlibro") && !busqueda.equals("")) {

            sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente, "
                    + "finPrestamo FROM Prestamo "
                    + "WHERE idLibro = " + busqueda;
        } else if (tipoBusqueda.equals("idprestamo") && !busqueda.equals("")) {
            sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente, "
                    + "finPrestamo FROM Prestamo "
                    + "WHERE idPrestamo = " + busqueda;
        } else {
            sqlPrestamos = "SELECT idPrestamo, idLibro, idCliente,"
                    + " finPrestamo FROM Prestamo";
        }

        //sentencias incompletas para clientes y libros
        String sqlClientes = "SELECT idUsuario, dni"
                + " FROM Cliente WHERE idUsuario IN (";
        String sqlLibros = "SELECT idLibro, titulo FROM Libro WHERE idLibro IN (";

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;
        //Sirve para hacer o no busqueda de clientes y libros
        boolean hayPrestamos = false;
        //ArrayList de id de libros y clientes que se relacionan con los prestamos
        ArrayList<Integer> usuariosBuscar = new ArrayList<Integer>();
        ArrayList<Integer> librosBuscar = new ArrayList<Integer>();

        //necesitamos ArrayList vacios para luego usarlos
        this.prestamos.clear();
        this.clientes.clear();
        this.libros.clear();

        //Busqueda y llenado de ArrayList prestamos
        sentencia = conexion.prepareStatement(sqlPrestamos);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayPrestamos = true; //Se hace busqueda de libros y clientes
            Prestamo prestamo = new Prestamo();
            int idPrestamo = resultadoBusqueda.getInt("idPrestamo");
            int idLibro = resultadoBusqueda.getInt("idLibro");
            int idCliente = resultadoBusqueda.getInt("idCliente");
            Date finPrestamo = resultadoBusqueda.getDate("finPrestamo");

            //identificación de que clientes y libros buscar
            usuariosBuscar.add(idCliente);
            librosBuscar.add(idLibro);

            //ponemos los atributos y lo guardamos en el array
            prestamo.setId(idPrestamo);
            prestamo.setIdLibro(idLibro);
            prestamo.setIdCliente(idCliente);
            prestamo.setFechaLimite(finPrestamo);
            this.prestamos.add(prestamo);
        }
        resultadoBusqueda.close();
        sentencia.close();

        if (hayPrestamos) {
            //primero eliminamos duplicados del ArrayList de clientes
            Set<Integer> clientesSinDup = new HashSet<Integer>(usuariosBuscar);
            ArrayList<Integer> clientes = new ArrayList<Integer>(clientesSinDup);

            //Creamos las sentencias completas para cliente y libro
            sqlClientes = sqlClientes + generarStringBusqueda(clientes);
            sqlLibros = sqlLibros + generarStringBusqueda(librosBuscar);

            //primero buscamos clientes
            sentencia = conexion.prepareStatement(sqlClientes);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Cliente cliente = new Cliente();
                int idCliente = resultadoBusqueda.getInt("idUsuario");
                String dni = resultadoBusqueda.getString("dni");

                //ponemos los atributos y lo guardamos en el array
                cliente.setId(idCliente);
                cliente.setDni(dni);
                this.clientes.add(cliente);
            }
            resultadoBusqueda.close();
            sentencia.close();

            //Busqueda de Libros
            sentencia = conexion.prepareStatement(sqlLibros);
            resultadoBusqueda = sentencia.executeQuery();
            while (resultadoBusqueda.next()) {
                Libro libro = new Libro();
                int idLibro = resultadoBusqueda.getInt("idLibro");
                String titulo = resultadoBusqueda.getString("titulo");

                //ponemos los atributos y lo guardamos en el array
                libro.setId(idLibro);
                libro.setTitulo(titulo);
                this.libros.add(libro);
            }
            resultadoBusqueda.close();
            sentencia.close();
        }
        return hayPrestamos;
    }

    /**
     * Método que llena la tabla con los ArrayList Prestamos, Clientes y Libros
     *
     * @param tabla tablaDevoluciones de VentanaDevolucion
     */
    public void llenarTablaDevoluciones(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        //El formato de fecha será "dd-MM-yyyy"
        SimpleDateFormat formateoFecha = new SimpleDateFormat("dd-MM-yyyy");

        modelo.setRowCount(0); //vaciamos la tabla

        //por cada prestamo buscamos su cliente y libro correspondiente.
        for (Prestamo prestamo : this.prestamos) {
            String dniCliente = "";
            String titulo = "";
            String fFinPrestamo = formateoFecha.format(prestamo.getFechaLimite());

            for (Cliente cliente : this.clientes) {
                if (cliente.getId() == prestamo.getIdCliente()) {
                    dniCliente = cliente.getDni();
                    break;
                }
            }

            for (Libro libro : this.libros) {
                if (libro.getId() == prestamo.getIdLibro()) {
                    titulo = libro.getTitulo();
                    break;
                }
            }
            //guardamos en un array de Object el resultado de la correspondencia
            Object[] row = {
                prestamo.getId(),
                dniCliente,
                prestamo.getIdLibro(),
                titulo,
                fFinPrestamo};
            modelo.addRow(row); //añadimos una fila

        }
    }

    /**
     * Metodo que borra un prestamo, además comprueba que lo devuelva a tiempo,
     * si no lo devuelve a tiempo se le aplica una sancion y si sobrepasa las
     * sanciones maximas también recibe un bloqueo permanente, Cambia la
     * cantidad de sanciones y prestamos activos del cliente también
     *
     * @param idPrestamo id del prestamo a eliminar
     * @param conexion Conexión a la BBDD
     * @return true si devuelve el libro false si es lo contrario
     */
    public boolean devolverLibro(int idPrestamo, Connection conexion) {
        boolean libroDevuelto = false;
        //Se preparan las sentencias, se usan en este orden
        String sqlPrestamo = "SELECT idCliente, idLibro, finPrestamo "
                + "FROM Prestamo "
                + "WHERE idPrestamo = " + idPrestamo;
        String sqlSelectCliente = "SELECT numSanciones, dni FROM Cliente "
                + "WHERE idUsuario = ?";
        String sqlInsertSancion = "INSERT INTO Sancion (idCliente, dni, motivo, diaFinSancion) "
                + "VALUES (?, ?, ?, ?)";
        String sqlClienteSancion = "UPDATE Cliente "
                + "SET estaPenalizado = true, numSanciones = numSanciones + 1 "
                + "WHERE idUsuario = ?";
        String sqlClienteBloqueo = "UPDATE Cliente "
                + "SET estaPenalizadoPerm = true "
                + "WHERE idUsuario = ?";
        String sqlDetelePrestamo = "DELETE FROM Prestamo WHERE idPrestamo = ?;";
        String sqlCliente = "UPDATE Cliente "
                + "SET numPrestamosActivos = numPrestamosActivos - 1 "
                + "WHERE idUsuario = ?";
        String sqlLibro = "UPDATE Libro SET enPrestamo = false "
                + "WHERE enPrestamo = true AND idLibro = ? ";

        PreparedStatement sentenciaPrestamo = null;
        PreparedStatement sentenciaSelectCliente = null;
        PreparedStatement sentenciaInsertSancion = null;
        PreparedStatement sentenciaClienteSancion = null;
        PreparedStatement sentenciaClienteBloqueo = null;
        PreparedStatement sentenciaDeletePrestamo = null;
        PreparedStatement sentenciaCliente = null;
        PreparedStatement sentenciaLibro = null;

        ResultSet rsPrestamo = null;
        ResultSet rsCliente = null;

        int iFilasAfectadas = 0;
        int iIdCliente = 0;
        int iIdLibro = 0;
        String sDni = "";
        int iSancionesUsuario = 0;
        Date finPrestamo = null;
        try {
            sentenciaPrestamo = conexion.prepareStatement(sqlPrestamo);
            rsPrestamo = sentenciaPrestamo.executeQuery();
            //Primero se extrae informacion: idCliente, idLibro y finPrestamo
            if (rsPrestamo.next()) {
                iIdCliente = rsPrestamo.getInt(1);
                iIdLibro = rsPrestamo.getInt(2);
                finPrestamo = rsPrestamo.getDate(3);
            }
            rsPrestamo.close();
            sentenciaPrestamo.close();

            //Si encuentra el prestamo
            if (iIdCliente > 0 && iIdLibro > 0) {

                sentenciaSelectCliente = conexion.prepareStatement(sqlSelectCliente);
                sentenciaSelectCliente.setInt(1, iIdCliente);
                rsCliente = sentenciaSelectCliente.executeQuery();
                //recogemos innformación de las sanciones del usuario y el dni
                if (rsCliente.next()) {
                    iSancionesUsuario = rsCliente.getInt(1);
                    sDni = rsCliente.getString(2);

                    rsCliente.close();
                    sentenciaSelectCliente.close();

                    Date hoy = new Date(System.currentTimeMillis());

                    //Si la fecha de hoy es mas tarde que fin de prestamo
                    if (hoy.after(finPrestamo)) {
                        Calendar calendar = Calendar.getInstance();
                        calendar.add(Calendar.DAY_OF_MONTH, this.tiempoSancion);
                        Date finSancion = new Date(calendar.getTimeInMillis());

                        //Se sanciona al cliente
                        sentenciaInsertSancion = conexion.prepareStatement(sqlInsertSancion);
                        sentenciaInsertSancion.setInt(1, iIdCliente);
                        sentenciaInsertSancion.setString(2, sDni);
                        sentenciaInsertSancion.setString(3, "Devolución tardia "
                                + "del libro con ID: " + iIdLibro);
                        sentenciaInsertSancion.setDate(4, finSancion);
                        sentenciaInsertSancion.executeUpdate();
                        sentenciaInsertSancion.close();

                        // y se aumenta el numero de sanciones y su estado pasa a sancionado
                        sentenciaClienteSancion = conexion.prepareStatement(sqlClienteSancion);
                        sentenciaClienteSancion.setInt(1, iIdCliente);
                        sentenciaClienteSancion.executeUpdate();
                        sentenciaClienteSancion.close();

                        //Si tiene el mismo numero de sanciones que el limite, se le bloquea
                        if ((iSancionesUsuario + 1) >= this.maxSancionesPorUsuario) {
                            sentenciaClienteBloqueo = conexion.prepareStatement(sqlClienteBloqueo);
                            sentenciaClienteBloqueo.setInt(1, iIdCliente);
                            sentenciaClienteBloqueo.executeUpdate();
                            sentenciaClienteBloqueo.close();

                        }

                    }

                }

                // Se borra el prestamo.
                sentenciaDeletePrestamo = conexion.prepareStatement(sqlDetelePrestamo);
                sentenciaDeletePrestamo.setInt(1, idPrestamo);

                iFilasAfectadas = sentenciaDeletePrestamo.executeUpdate();
                sentenciaDeletePrestamo.close();
                if (iFilasAfectadas > 0) {
                    //Se reduce en 1 el numero de prestamos activos
                    sentenciaCliente = conexion.prepareStatement(sqlCliente);
                    sentenciaCliente.setInt(1, iIdCliente);
                    sentenciaCliente.executeUpdate();

                    //El libro pasa a ser prestable
                    sentenciaLibro = conexion.prepareStatement(sqlLibro);
                    sentenciaLibro.setInt(1, iIdLibro);
                    int iFilasAfectadas3 = sentenciaLibro.executeUpdate();

                    sentenciaCliente.close();
                    sentenciaLibro.close();

                    //Solo si se cambia el libro a estado false enPrestamo se considera devuelto.
                    if (iFilasAfectadas3 > 0) {
                        libroDevuelto = true;
                    }

                }
                if (!libroDevuelto) {
                    conexion.rollback();
                }

            }
        } catch (SQLException ex) {
            try {
                libroDevuelto = false;
                conexion.rollback();
            } catch (SQLException ex1) {
            } finally {
                try {
                    conexion.close();
                } catch (SQLException ex1) {
                }
            }
        }
        return libroDevuelto;
    }

    //VentanaColecciones
    /**
     * Metodo que llena el ArrayList de libros; El metodo tiene un string que
     * Cambia el metodo de busqueda y busca segun el id, título, autor , isbn o
     * busqueda de todos.
     *
     * @param conexion Conexión a la BBDD.
     * @param tipoBusqueda String = id , titulo, autor o isbn.
     * @param busqueda Lo que se busca
     * @return true si hay libros y false si lo contrario
     * @throws SQLException Error de conexión a la BBDD
     */
    public boolean consultarLibros(Connection conexion, String tipoBusqueda,
            String busqueda) throws SQLException {
        //Se prepara las sentencias
        String sqlLibros = "";
        //if que identifica que tipo de busqueda será
        if (tipoBusqueda.equals("id") && !busqueda.equals("")) {
            sqlLibros = "SELECT idLibro, titulo, autor, ISBN, esPrestable "
                    + "FROM Libro "
                    + "WHERE idLibro = " + busqueda.trim();
        } else if (tipoBusqueda.equals("titulo") && !busqueda.equals("")) {
            //En título es busqueda aproximada
            sqlLibros = "SELECT idLibro, titulo, autor, ISBN, esPrestable "
                    + "FROM Libro "
                    + "WHERE titulo LIKE '%" + busqueda.trim() + "%'";
        } else if (tipoBusqueda.equals("autor") && !busqueda.equals("")) {
            //En autor es busqueda aproximada
            sqlLibros = "SELECT idLibro, titulo, autor, ISBN, esPrestable "
                    + "FROM Libro "
                    + "WHERE autor LIKE '%" + busqueda.trim() + "%'";
        } else if (tipoBusqueda.equals("isbn") && !busqueda.equals("")) {
            //En ISBN es busqueda aproximada por el final
            sqlLibros = "SELECT idLibro, titulo, autor, ISBN, esPrestable "
                    + "FROM Libro "
                    + "WHERE ISBN LIKE '" + busqueda.trim() + "%'";
        } else {
            sqlLibros = "SELECT idLibro, titulo, autor, ISBN, esPrestable "
                    + "FROM Libro";
        }
        boolean hayLibros = false;

        this.libros.clear();

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de ArrayList Libros
        sentencia = conexion.prepareStatement(sqlLibros);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayLibros = true; //Aqui el metodo devuelve true.
            Libro libro = new Libro();
            int idLibro = resultadoBusqueda.getInt("idLibro");
            String titulo = resultadoBusqueda.getString("titulo");
            String autor = resultadoBusqueda.getString("autor");
            String isbn = resultadoBusqueda.getString("ISBN");
            boolean esPrestable = resultadoBusqueda.getBoolean("esPrestable");

            //ponemos los atributos y lo guardamos en el array
            libro.setId(idLibro);
            libro.setTitulo(titulo);
            libro.setAutor(autor);
            libro.setIsbn(isbn);
            libro.setEsPrestable(esPrestable);
            this.libros.add(libro);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return hayLibros;
    }

    /**
     * Método que llena la tabla con el ArrayList libros
     *
     * @param tabla tablaLibro de VentanaColecciones.
     */
    public void llenarTablaColecciones(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        modelo.setRowCount(0); //vaciamos la tabla

        //Recorremos cada libro para meterlo en la tabla
        for (Libro libro : this.libros) {
            int idLibro = libro.getId();
            String titulo = libro.getTitulo();
            String autor = libro.getAutor();
            String isbn = libro.getIsbn();
            boolean bloqueado = !libro.isEsPrestable();

            //guardamos en un array de Object el resultado
            Object[] row = {
                idLibro,
                titulo,
                autor,
                isbn,
                bloqueado};
            modelo.addRow(row); //añadimos una fila
        }

    }

    /**
     * Metodo que busca un libro que se pretende modificar más adelante
     *
     * @param conexion Conexión a la BBDD
     * @param libro Libro donde se almacena la información.
     * @param busqueda ID de libro.
     * @return true si encontrado false si lo contrario.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean BuscarLibroModificar(Connection conexion, Libro libro,
            String busqueda) throws SQLException {
        //Se prepara las sentencias

        String sqlLibros = "SELECT idLibro, titulo, autor, ISBN, "
                + "fechaPublicacion, esPrestable, estado "
                + "FROM Libro "
                + "WHERE idLibro = " + busqueda;
        boolean libroEncontrado = false;

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de objeto Libro
        sentencia = conexion.prepareStatement(sqlLibros);
        resultadoBusqueda = sentencia.executeQuery();
        if (resultadoBusqueda.next()) {
            libroEncontrado = true; //Libro encontrado
            int idLibro = resultadoBusqueda.getInt("idLibro");
            String titulo = resultadoBusqueda.getString("titulo");
            String autor = resultadoBusqueda.getString("autor");
            String isbn = resultadoBusqueda.getString("ISBN");
            Date fechaPublicacion = resultadoBusqueda.getDate("fechaPublicacion");
            boolean esPrestable = resultadoBusqueda.getBoolean("esPrestable");
            String estado = resultadoBusqueda.getString("estado");

            //ponemos los atributos y lo guardamos en el Libro
            libro.setId(idLibro);
            libro.setTitulo(titulo);
            libro.setAutor(autor);
            libro.setIsbn(isbn);
            libro.setFechaAdquisicion(fechaPublicacion);
            libro.setEsPrestable(esPrestable);
            libro.setEstado(estado);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return libroEncontrado;
    }

    /**
     * Método que borra un libro y devuelve información de si lo consigue o no.
     *
     * @param idLibro ID del libro a borrar.
     * @param conexion Conexión a la BBDD.
     * @return true si lo borra, y false si no
     * @throws SQLException
     */
    public boolean borrarLibro(String idLibro, Connection conexion) throws SQLException {
        boolean libroBorrado = false;
        String sqlDeteleLibro = "DELETE FROM Libro "
                + "WHERE idLibro = " + idLibro;

        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        sentencia = conexion.prepareStatement(sqlDeteleLibro);
        //recoge si se ha borrado alguna instancia
        filasAfectadas = sentencia.executeUpdate();

        //si borra 1 pone el booleano a true si borra más de 1 lo pone a false y hace rollback
        if (filasAfectadas > 0) {
            libroBorrado = true;
        }
        if (filasAfectadas > 1) {
            // Si se borra más de 1 se hace rollBack
            conexion.rollback();
            libroBorrado = false;
        }

        return libroBorrado;
    }

    //VentanaCrearLibro
    /**
     * Metodo que da de alta un libro
     *
     * @param titulo Título del libro.
     * @param autor Autor del libro.
     * @param isbn ISBN del libro.
     * @param fechaPublicacion Fecha de publicación del libro
     * @param esPrestable Si se puede prestar
     * @param estado breve descripción del estado del libro
     * @param conexion Conexion a la BBDD
     * @return true si introduce libro false si no introduce.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean crearlibro(String titulo, String autor, String isbn,
            Date fechaPublicacion, boolean esPrestable, String estado, Connection conexion) throws SQLException {
        boolean libroCreado = false;
        String sqlInsertLibro = "INSERT INTO Libro (titulo, autor, ISBN, "
                + "fechaPublicacion, esPrestable, estado) "
                + "VALUES (?, ?, ?, ?, ?, ?)";
        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        //Ponemos todos los datos recogidos en la sentencia,
        sentencia = conexion.prepareStatement(sqlInsertLibro);
        sentencia.setString(1, titulo);
        sentencia.setString(2, autor);
        sentencia.setString(3, isbn);
        sentencia.setDate(4, fechaPublicacion);
        sentencia.setBoolean(5, esPrestable);
        sentencia.setString(6, estado);

        filasAfectadas = sentencia.executeUpdate();

        // si se crea una fila devuelve true.
        if (filasAfectadas > 0) {
            libroCreado = true;
        }

        return libroCreado;
    }

    //VentanaModificarLibro
    /**
     * Metodo que modifica un libro haciendo un insert
     *
     * @param titulo Título del libro.
     * @param autor Autor del libro.
     * @param isbn ISBN del libro
     * @param fechaPublicacion fecha de publicación del libro.
     * @param esPrestable si el libro se puede prestar
     * @param estado breve descripción del estado del libro.
     * @param idLibro id del libro
     * @param conexion Conexión a la BBDD
     * @return true si se modifica, false si no.
     * @throws SQLException Error en la conexión a la BBDD
     */
    public boolean modificarLibro(String titulo, String autor, String isbn,
            Date fechaPublicacion, boolean esPrestable, String estado,
            int idLibro, Connection conexion) throws SQLException {
        String sqlModificar = "UPDATE Libro SET titulo = ?, autor = ?, ISBN = ?, "
                + "fechaPublicacion = ?, esPrestable = ?, estado = ? "
                + "WHERE idLibro = ?";
        boolean modificado = false;
        int filasAfectadas = 0;

        PreparedStatement sentencia = null;

        //Se introducen todos los datos necesarios para la modificación
        sentencia = conexion.prepareStatement(sqlModificar);
        sentencia.setString(1, titulo);
        sentencia.setString(2, autor);
        sentencia.setString(3, isbn);
        sentencia.setDate(4, fechaPublicacion);
        sentencia.setBoolean(5, esPrestable);
        sentencia.setString(6, estado);
        sentencia.setInt(7, idLibro);

        filasAfectadas = sentencia.executeUpdate();

        //Si lo modifica devuelve true
        if (filasAfectadas > 0) {
            modificado = true;
        }
        sentencia.close();

        return modificado;
    }

    //VentanaCrearCliente
    /**
     * Metodo que da de alta un cliente.
     *
     * @param dni dni del cliente.
     * @param nombre nombre del cliente.
     * @param apellidos apellidos del cliente.
     * @param direccion dirección del cliente.
     * @param fechaNacimiento fecha de nacimiento del cliente.
     * @param telefono telefono del cliente.
     * @param email email del cliente.
     * @param conexion Conexión a la BBDD.
     * @return true si crea cliente false si no lo consigue.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean crearCliente(String dni, String nombre, String apellidos,
            String direccion, Date fechaNacimiento, String telefono,
            String email, Connection conexion) throws SQLException {
        boolean clienteCreado = false;
        String sqlInsertCliente = "INSERT INTO Cliente (dni, nombre, apellidos, "
                + "direccion, fechaNacimiento, telefono, email) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        //Se introducen los datos en la sentencia.
        sentencia = conexion.prepareStatement(sqlInsertCliente);
        sentencia.setString(1, dni);
        sentencia.setString(2, nombre);
        sentencia.setString(3, apellidos);
        sentencia.setString(4, direccion);
        sentencia.setDate(5, fechaNacimiento);
        sentencia.setString(6, telefono);
        sentencia.setString(7, email);

        filasAfectadas = sentencia.executeUpdate();

        //Si devuelve true ha creado un cliente.
        if (filasAfectadas > 0) {
            clienteCreado = true;
        }

        return clienteCreado;
    }

    //VentanaCrearTrabajador
    /**
     * Método que da de alta a un trabajador.
     *
     * @param dni DNI del trabajador.
     * @param nombre nombre del trabajador.
     * @param apellidos Apellidos del trabajador.
     * @param direccion Dirección del trabajador.
     * @param fechaNacimiento Fecha de nacimiento del trabajador.
     * @param telefono Teléfono del trabajador.
     * @param email Email del trabajador.
     * @param nombreUsuario Usuario del trabajador.
     * @param password Contraseña del trabajador.
     * @param rol ID de rol del trabajador.
     * @param conexion Conexión a la BBDD.
     * @return true si crea un trabajador y false si no lo hace.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean crearTrabajador(String dni, String nombre, String apellidos,
            String direccion, Date fechaNacimiento, String telefono,
            String email, String nombreUsuario, String password, int rol,
            Connection conexion) throws SQLException {
        boolean clienteCreado = false;
        String sqlInsertTrabajador = "INSERT INTO Trabajador (dni, nombre, apellidos, "
                + "direccion, fechaNacimiento, telefono, email, nombreUsuario, "
                + "password, nivelRol) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        //Se introducen todos los datos necesarios para crear un trabajador
        String cPassword = Login.cifradoSHA256(password);
        sentencia = conexion.prepareStatement(sqlInsertTrabajador);
        sentencia.setString(1, dni);
        sentencia.setString(2, nombre);
        sentencia.setString(3, apellidos);
        sentencia.setString(4, direccion);
        sentencia.setDate(5, fechaNacimiento);
        sentencia.setString(6, telefono);
        sentencia.setString(7, email);
        sentencia.setString(8, nombreUsuario);
        sentencia.setString(9, cPassword);
        sentencia.setInt(10, rol);

        filasAfectadas = sentencia.executeUpdate();

        //Si se crea un trabajador devuelve true.
        if (filasAfectadas > 0) {
            clienteCreado = true;
        }

        return clienteCreado;
    }

    //VentanaModificarCliente
    /**
     * Metodo que modifica un cliente.
     *
     * @param dni DNI del cliente.
     * @param nombre Nombre del cliente.
     * @param apellidos Apellidos del cliente.
     * @param direccion Dirección del cliente.
     * @param fechaNacimiento Fecha de nacimiento del cliente.
     * @param telefono Teléfono del cliente.
     * @param email Email del cliente.
     * @param idUsuario ID del cliente.
     * @param conexion Conexión a la BBDD.
     * @return Return true si se modifica un cliente false si no modifica nada.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean modificarCliente(String dni, String nombre, String apellidos,
            String direccion, Date fechaNacimiento, String telefono,
            String email, int idUsuario, Connection conexion) throws SQLException {
        boolean clienteModificado = false;
        String sqlUpdateCliente = "UPDATE Cliente SET dni = ?, nombre = ?, apellidos = ?, "
                + "direccion = ?, fechaNacimiento = ?, telefono = ?, email = ? "
                + "WHERE idUsuario = ?";
        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        //Se introduce todos los datos necesarios para modificar un cliente
        sentencia = conexion.prepareStatement(sqlUpdateCliente);
        sentencia.setString(1, dni);
        sentencia.setString(2, nombre);
        sentencia.setString(3, apellidos);
        sentencia.setString(4, direccion);
        sentencia.setDate(5, fechaNacimiento);
        sentencia.setString(6, telefono);
        sentencia.setString(7, email);
        sentencia.setInt(8, idUsuario);

        filasAfectadas = sentencia.executeUpdate();

        //Si se modifica devuelve true.
        if (filasAfectadas > 0) {
            clienteModificado = true;
        }
        sentencia.close();

        return clienteModificado;
    }

    //VentanaModificarTrabajador
    /**
     * Método que modifica un trabajador.
     *
     * @param dni DNI del trabajador.
     * @param nombre Nombre del trabajador.
     * @param apellidos Apellidos del trabajador.
     * @param direccion Dirección del trabajador.
     * @param fechaNacimiento Fecha de nacimiento del trabajador.
     * @param telefono Teléfono del trabajador.
     * @param email Email del trabajador.
     * @param nombreUsuario Usuario del trabajador.
     * @param password Contraseña del trabajador.
     * @param rol ID de rol del trabajador.
     * @param idTrabajador ID del trabajador.
     * @param cambiarLogin true = cambiar también usuario y contraseña false =
     * no
     * @param activo Si trabaja aun el trabajador.
     * @param conexion Conexión a la BBDD.
     * @return true si lo modifica, false si no modifica.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean modificarTrabajador(String dni, String nombre, String apellidos,
            String direccion, Date fechaNacimiento, String telefono,
            String email, String nombreUsuario, String password, int rol,
            int idTrabajador, boolean cambiarLogin, boolean activo,
            Connection conexion) throws SQLException {
        boolean clienteCreado = false;

        String sqlUpdateTrabajador = "";
        //Si hay que cambiar los datos de conexión el update es diferente
        if (cambiarLogin) {
            sqlUpdateTrabajador = "UPDATE Trabajador SET dni = ?, nombre = ?, apellidos = ?, "
                    + "direccion = ?, fechaNacimiento = ?, telefono = ?, "
                    + "email = ?, nivelRol = ?, activo = ?, nombreUsuario = ?, "
                    + "password = ? "
                    + "WHERE idUsuario = ?";
        } else {
            sqlUpdateTrabajador = "UPDATE Trabajador SET dni = ?, nombre = ?, apellidos = ?, "
                    + "direccion = ?, fechaNacimiento = ?, telefono = ?, "
                    + "email = ?, nivelRol = ?, activo = ? "
                    + "WHERE idUsuario = ?";
        }

        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        //Se meten los datos en la sentencia
        sentencia = conexion.prepareStatement(sqlUpdateTrabajador);
        sentencia.setString(1, dni);
        sentencia.setString(2, nombre);
        sentencia.setString(3, apellidos);
        sentencia.setString(4, direccion);
        sentencia.setDate(5, fechaNacimiento);
        sentencia.setString(6, telefono);
        sentencia.setString(7, email);
        sentencia.setInt(8, rol);
        sentencia.setBoolean(9, activo);
        //Si cambia datos de login o no se meten más o menos datos
        if (cambiarLogin) {
            String cPassword = Login.cifradoSHA256(password);
            sentencia.setString(10, nombreUsuario);
            sentencia.setString(11, cPassword);
            sentencia.setInt(12, idTrabajador);
        } else {
            sentencia.setInt(10, idTrabajador);
        }

        filasAfectadas = sentencia.executeUpdate();

        if (filasAfectadas > 0) {
            clienteCreado = true;
        }
        sentencia.close();

        return clienteCreado;
    }

    //VentanaClientesTrabajadores
    /**
     * Metodo que busca un cliente y recoge su información en un objeto de tipo
     * Cliente.
     *
     * @param conexion Conexión a la BBDD
     * @param cliente Cliente que se llena de información del cliente a
     * modificar.
     * @param busqueda idUsuario del cliente.
     * @return true si lo encuentra false si no lo encuentra
     * @throws SQLException Error de conexión a la BBDD
     */
    public boolean BuscarClienteModificar(Connection conexion, Cliente cliente,
            String busqueda) throws SQLException {
        //Se prepara las sentencias

        String sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, "
                + "direccion, fechaNacimiento, telefono, email, numPrestamosActivos, "
                + "numSanciones, estaPenalizado, estaPenalizadoPerm "
                + "FROM Cliente "
                + "WHERE idUsuario = " + busqueda;
        boolean clienteEncontrado = false;

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de objeto Cliente
        sentencia = conexion.prepareStatement(sqlCliente);
        resultadoBusqueda = sentencia.executeQuery();
        if (resultadoBusqueda.next()) {
            clienteEncontrado = true; //Cliente encontrado
            int idCliente = resultadoBusqueda.getInt("idUsuario");
            String dni = resultadoBusqueda.getString("dni");
            String nombre = resultadoBusqueda.getString("nombre");
            String apellidos = resultadoBusqueda.getString("apellidos");
            String direccion = resultadoBusqueda.getString("direccion");
            Date nacimiento = resultadoBusqueda.getDate("fechaNacimiento");
            String telefono = resultadoBusqueda.getString("telefono");
            String email = resultadoBusqueda.getString("email");
            int numPrestamosActivos = resultadoBusqueda.getInt("numPrestamosActivos");
            int numSanciones = resultadoBusqueda.getInt("numSanciones");
            boolean estaPenalizado = resultadoBusqueda.getBoolean("estaPenalizado");
            boolean estaPenalizadoPerm = resultadoBusqueda.getBoolean("estaPenalizadoPerm");

            //ponemos los atributos y lo guardamos en el Cliente
            cliente.setId(idCliente);
            cliente.setDni(dni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellidos);
            cliente.setDireccion(direccion);
            cliente.setNacimiento(nacimiento);
            cliente.setTelefono(telefono);
            cliente.setEmail(email);
            cliente.setPrestamosActivos(numPrestamosActivos);
            cliente.setNumeroSanciones(numSanciones);
            cliente.setEstaCastigado(estaPenalizado);
            cliente.setEstaVetado(estaPenalizadoPerm);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return clienteEncontrado;
    }

    /**
     * Metodo que busca un trabajador y recoge su información en un objeto de
     * tipo trabajador.
     *
     * @param conexion Conexión a la BBDD.
     * @param trabajador trabajador que se llena de información del trabajador a
     * modificar.
     * @param busqueda ID del trabajador a modificar.
     * @return true si encuentra, false si no.
     * @throws SQLException
     */
    public boolean BuscarTrabajadorModificar(Connection conexion, Trabajador trabajador,
            String busqueda) throws SQLException {
        //Se prepara las sentencias

        String sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, "
                + "direccion, fechaNacimiento, telefono, email, nivelRol, "
                + "activo "
                + "FROM Trabajador "
                + "WHERE idUsuario = " + busqueda;
        boolean trabajadorEncontrado = false;

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de objeto Trabajador
        sentencia = conexion.prepareStatement(sqlTrabajador);
        resultadoBusqueda = sentencia.executeQuery();

        if (resultadoBusqueda.next()) {
            trabajadorEncontrado = true; //Cliente encontrado
            int idCliente = resultadoBusqueda.getInt("idUsuario");
            String dni = resultadoBusqueda.getString("dni");
            String nombre = resultadoBusqueda.getString("nombre");
            String apellidos = resultadoBusqueda.getString("apellidos");
            String direccion = resultadoBusqueda.getString("direccion");
            Date nacimiento = resultadoBusqueda.getDate("fechaNacimiento");
            String telefono = resultadoBusqueda.getString("telefono");
            String email = resultadoBusqueda.getString("email");
            int nivelRol = resultadoBusqueda.getInt("nivelRol");
            boolean activo = resultadoBusqueda.getBoolean("activo");

            //Guardamos la información en el Cliente
            trabajador.setId(idCliente);
            trabajador.setDni(dni);
            trabajador.setNombre(nombre);
            trabajador.setApellidos(apellidos);
            trabajador.setDireccion(direccion);
            trabajador.setNacimiento(nacimiento);
            trabajador.setTelefono(telefono);
            trabajador.setEmail(email);
            trabajador.setRol(nivelRol);
            trabajador.setEstaActivo(activo);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return trabajadorEncontrado;
    }

    /**
     * Método que borra un cliente.
     *
     * @param idCliente ID de cliente a borrar.
     * @param conexion Conexión a la BBDD.
     * @return true si borra cliente. False si no.
     * @throws SQLException Error de conexión a la BBDD
     */
    public boolean borrarCliente(String idCliente, Connection conexion) throws SQLException {
        boolean clienteBorrado = false;
        String sqlDeleteCliente = "DELETE FROM Cliente "
                + "WHERE idUsuario = " + idCliente;

        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        sentencia = conexion.prepareStatement(sqlDeleteCliente);
        filasAfectadas = sentencia.executeUpdate();

        if (filasAfectadas > 0) {
            clienteBorrado = true;
        }
        if (filasAfectadas > 1) {
            // Si se borra más de 1 se hace rollBack
            conexion.rollback();
            clienteBorrado = false;
        }

        return clienteBorrado;
    }

    /**
     * Método que comprueba si un cliente tiene prestamos, es util para antes de
     * borrarlo para mantener la consistencia de la tabla
     *
     * @param idCliente ID de cliente a consultar.
     * @param conexion Conexión a la BBDD.
     * @return true si no tiene prestamos, false si tiene.
     * @throws SQLException Error de conexion a la BBDD.
     */
    public boolean checkPrestamos(String idCliente, Connection conexion) throws SQLException {
        boolean clienteSinPrestamos = false;
        String sqlCountPrestamos = "SELECT COUNT(*) "
                + "FROM Prestamo "
                + "WHERE idCliente = " + idCliente;

        PreparedStatement sentencia = null;

        ResultSet rsCount = null;
        int iPrestamosActivos = 0;

        sentencia = conexion.prepareStatement(sqlCountPrestamos);
        rsCount = sentencia.executeQuery();

        if (rsCount.next()) {
            iPrestamosActivos = rsCount.getInt(1);

            rsCount.close();
            sentencia.close();

            //si tiene 0 prestamos devuelve true
            if (iPrestamosActivos == 0) {
                clienteSinPrestamos = true;
            }
        }

        return clienteSinPrestamos;
    }

    /**
     * Método que borra trabajador de la BBDD.
     *
     * @param idTrabajador ID de trabajador a borrar
     * @param conexion Conexión a la BBDD.
     * @return true si borra, false si no borra
     * @throws SQLException Error de conexión a la BBDD
     */
    public boolean borrarTrabajador(String idTrabajador, Connection conexion) throws SQLException {
        boolean trabajadadorBorrado = false;
        String sqlDeleteTrabajador = "DELETE FROM Trabajador "
                + "WHERE idUsuario = " + idTrabajador;

        PreparedStatement sentencia = null;
        int filasAfectadas = 0;

        sentencia = conexion.prepareStatement(sqlDeleteTrabajador);
        filasAfectadas = sentencia.executeUpdate();

        if (filasAfectadas > 0) {
            trabajadadorBorrado = true;
        }
        if (filasAfectadas > 1) {
            // Si se borra más de 1 se hace rollBack
            conexion.rollback();
            trabajadadorBorrado = false;
        }

        return trabajadadorBorrado;
    }

    /**
     * Método que llena el ArrayList clientes con datos para
     * VentanaClientesTrabajadores.
     *
     * @param conexion Conexión a la BBDD.
     * @param tipoBusqueda puede ser "dni", "id", "email", "apellidos" o
     * ""(busqueda general).
     * @param busqueda lo que se busca, si "" se hace busqueda general.
     * @return true si hay clientes, false si no los hay.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean consultarClientes(Connection conexion, String tipoBusqueda,
            String busqueda) throws SQLException {
        //Se prepara las sentencias
        String sqlCliente = "";
        //if que identifica que tipo de busqueda será
        if (tipoBusqueda.equals("dni") && !busqueda.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, email, "
                    + "estaPenalizado "
                    + "FROM Cliente "
                    + "WHERE dni = " + busqueda.trim();
        } else if (tipoBusqueda.equals("id") && !busqueda.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, email, "
                    + "estaPenalizado "
                    + "FROM Cliente "
                    + "WHERE idUsuario = " + busqueda.trim();
        } else if (tipoBusqueda.equals("email") && !busqueda.equals("")) {

            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, email, "
                    + "estaPenalizado "
                    + "FROM Cliente "
                    + "WHERE email LIKE '%" + busqueda.trim() + "%'";
        } else if (tipoBusqueda.equals("apellidos") && !busqueda.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, email, "
                    + "estaPenalizado "
                    + "FROM Cliente "
                    + "WHERE apellidos LIKE '%" + busqueda.trim() + "%'";
        } else {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, email, "
                    + "estaPenalizado "
                    + "FROM Cliente";
        }
        boolean hayClientes = false;

        this.clientes.clear(); //Se limpia el ArrayList

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de ArrayList clientes
        sentencia = conexion.prepareStatement(sqlCliente);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayClientes = true;
            Cliente cliente = new Cliente();
            int idCliente = resultadoBusqueda.getInt("idUsuario");
            String dni = resultadoBusqueda.getString("dni");
            String nombre = resultadoBusqueda.getString("nombre");
            String apellidos = resultadoBusqueda.getString("apellidos");
            String email = resultadoBusqueda.getString("email");
            boolean estaPenalizado = resultadoBusqueda.getBoolean("estaPenalizado");

            //ponemos los atributos y lo guardamos en el array
            cliente.setId(idCliente);
            cliente.setDni(dni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellidos);
            cliente.setEmail(email);
            cliente.setEstaCastigado(estaPenalizado);
            this.clientes.add(cliente);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return hayClientes;
    }

    /**
     * Método que llena el ArrayList trabajadores con datos para
     * VentanaClientesTrabajadores tiene distintos tipos de búsqueda.
     *
     * @param conexion Conexión a la BBDD.
     * @param tipoBusqueda puede ser "dni", "id", "email", "apellidos" o
     * ""(busqueda general).
     * @param busqueda lo que se busca, si "" se hace busqueda general
     * @return true si hay trabajadores, false si no los hay.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean consultarTrabajadores(Connection conexion, String tipoBusqueda,
            String busqueda) throws SQLException {
        //Se prepara las sentencias
        String sqlTrabajador = "";
        //if que identifica que tipo de busqueda será
        if (tipoBusqueda.equals("dni") && !busqueda.equals("")) {
            sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, email "
                    + "FROM Trabajador "
                    + "WHERE nivelRol < 5 AND "
                    + "dni = " + busqueda.trim();
        } else if (tipoBusqueda.equals("id") && !busqueda.equals("")) {
            sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, email "
                    + "FROM Trabajador "
                    + "WHERE nivelRol < 5 AND "
                    + "idUsuario = " + busqueda.trim();
        } else if (tipoBusqueda.equals("email") && !busqueda.equals("")) {

            sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, email "
                    + "FROM Trabajador "
                    + "WHERE nivelRol < 5 AND "
                    + "email LIKE '%" + busqueda.trim() + "%'";
        } else if (tipoBusqueda.equals("apellidos") && !busqueda.equals("")) {
            sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, email "
                    + "FROM Trabajador "
                    + "WHERE nivelRol < 5 AND "
                    + "apellidos LIKE '%" + busqueda.trim() + "%'";
        } else {
            sqlTrabajador = "SELECT idUsuario, dni, nombre, apellidos, email "
                    + "FROM Trabajador "
                    + "WHERE nivelRol < 5";
        }
        boolean hayTrabajadores = false;

        this.trabajadores.clear(); //se vacia ArrayList

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de ArrayList trabajadores.
        sentencia = conexion.prepareStatement(sqlTrabajador);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayTrabajadores = true; //El metodo devuelve true
            Trabajador trabajador = new Trabajador();
            int idTrabajador = resultadoBusqueda.getInt("idUsuario");
            String dni = resultadoBusqueda.getString("dni");
            String nombre = resultadoBusqueda.getString("nombre");
            String apellidos = resultadoBusqueda.getString("apellidos");
            String email = resultadoBusqueda.getString("email");

            //ponemos los atributos y lo guardamos en el array
            trabajador.setId(idTrabajador);
            trabajador.setDni(dni);
            trabajador.setNombre(nombre);
            trabajador.setApellidos(apellidos);
            trabajador.setEmail(email);
            this.trabajadores.add(trabajador);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return hayTrabajadores;
    }

    /**
     * Método que llena la tabla con el ArrayList clientes
     *
     * @param tabla tablaClientes de VentanaClientesTrabajadores.
     */
    public void llenarTablaClientes(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        modelo.setRowCount(0); //vaciamos la tabla

        //Recorremos cada cliente para meterlo en la tabla
        for (Cliente cliente : this.clientes) {
            int idCliente = cliente.getId();
            String dni = cliente.getDni();
            String nombre = cliente.getNombre() + " " + cliente.getApellidos();
            String email = cliente.getEmail();
            boolean penalizado = cliente.isEstaCastigado();

            //guardamos en un array de Object el resultado
            Object[] row = {
                idCliente,
                dni,
                nombre,
                email,
                penalizado};
            modelo.addRow(row); //añadimos una fila
        }

    }

    /**
     * Método que llena la tabla con el ArrayList trabajadores
     *
     * @param tabla tablaTrabajadores de VentanaClientesTrabajadores.
     */
    public void llenarTablaTrabajadores(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        modelo.setRowCount(0); //vaciamos la tabla

        //Recorremos cada trabajador para meterlo en la tabla
        for (Trabajador trabajador : this.trabajadores) {
            int idTrabajador = trabajador.getId();
            String dni = trabajador.getDni();
            String nombre = trabajador.getNombre() + " " + trabajador.getApellidos();
            String email = trabajador.getEmail();

            //guardamos en un array de Object el resultado
            Object[] row = {
                idTrabajador,
                dni,
                nombre,
                email};
            modelo.addRow(row); //añadimos una fila
        }

    }

    //VentanaSanciones
    /**
     * Método que llena ArrayList clientes para VentanaSanciones, tiene
     * distintos tipos de búsqueda.
     *
     * @param conexion Conexión a la BBDD.
     * @param tipoBusqueda puede ser "dni", "id" o ""(Búsqueda general).
     * @param busqueda lo que se busca, si "" se hace búsqueda general
     * @return true si hay clientes, false si no.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean consultarClientesSanciones(Connection conexion, String tipoBusqueda,
            String busqueda) throws SQLException {
        //Se prepara las sentencias
        String sqlCliente = "";
        //if que identifica que tipo de busqueda será
        if (tipoBusqueda.equals("dni") && !busqueda.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, estaPenalizado, "
                    + "estaPenalizadoPerm "
                    + "FROM Cliente "
                    + "WHERE dni = " + busqueda.trim();
        } else if (tipoBusqueda.equals("id") && !busqueda.equals("")) {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, estaPenalizado, "
                    + "estaPenalizadoPerm "
                    + "FROM Cliente "
                    + "WHERE idUsuario = " + busqueda.trim();
        } else {
            sqlCliente = "SELECT idUsuario, dni, nombre, apellidos, estaPenalizado, "
                    + "estaPenalizadoPerm "
                    + "FROM Cliente";
        }
        boolean hayClientes = false;

        this.clientes.clear(); //Se vacia ArrayList

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de ArrayList Clientes
        sentencia = conexion.prepareStatement(sqlCliente);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            hayClientes = true;
            Cliente cliente = new Cliente();
            int idCliente = resultadoBusqueda.getInt("idUsuario");
            String dni = resultadoBusqueda.getString("dni");
            String nombre = resultadoBusqueda.getString("nombre");
            String apellidos = resultadoBusqueda.getString("apellidos");
            boolean estaPenalizado = resultadoBusqueda.getBoolean("estaPenalizado");
            boolean estaPenalizadoPerm = resultadoBusqueda.getBoolean("estaPenalizadoPerm");

            //ponemos los atributos y lo guardamos en el array
            cliente.setId(idCliente);
            cliente.setDni(dni);
            cliente.setNombre(nombre);
            cliente.setApellidos(apellidos);
            cliente.setEstaCastigado(estaPenalizado);
            cliente.setEstaVetado(estaPenalizadoPerm);
            this.clientes.add(cliente);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return hayClientes;
    }

    /**
     * Método que consulta las sanciones de un cliente para recoger los datos
     * para VentanaSanciones
     *
     * @param conexion Conexión a BBDD sql.
     * @param busqueda ID de cliente.
     * @return true si hay sanciones.
     * @throws SQLException Error de conexión a la BBDD.
     */
    public boolean consultarSanciones(Connection conexion,
            String busqueda) throws SQLException {
        //Se prepara la sentencia con la id de cliente.
        String sqlSanciones = "SELECT idSancion, dni, motivo, diaFinSancion "
                + "FROM Sancion "
                + "WHERE idCliente = " + busqueda;

        boolean haySanciones = false;

        this.sanciones.clear();

        PreparedStatement sentencia = null;
        ResultSet resultadoBusqueda = null;

        //Busqueda y llenado de ArrayList sanciones
        sentencia = conexion.prepareStatement(sqlSanciones);
        resultadoBusqueda = sentencia.executeQuery();
        while (resultadoBusqueda.next()) {
            haySanciones = true;
            Sancion sancion = new Sancion();
            int idSancion = resultadoBusqueda.getInt("idSancion");
            String dni = resultadoBusqueda.getString("dni");
            String motivo = resultadoBusqueda.getString("motivo");
            Date diaFinSancion = resultadoBusqueda.getDate("diaFinSancion");

            //ponemos los atributos y lo guardamos en el array
            sancion.setId(idSancion);
            sancion.setDni(dni);
            sancion.setMotivo(motivo);
            sancion.setFinSancion(diaFinSancion);
            this.sanciones.add(sancion);
        }
        resultadoBusqueda.close();
        sentencia.close();

        return haySanciones;
    }

    /**
     * Método que llena la tabla con el ArrayList clientes
     *
     * @param tabla tablaClientes de VentanaSanciones.
     */
    public void llenarTablaClientesSanciones(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();

        modelo.setRowCount(0); //vaciamos la tabla

        //Recorremos cada cliente para meterlo en la tabla
        for (Cliente cliente : this.clientes) {
            int idCliente = cliente.getId();
            String dni = cliente.getDni();
            String nombre = cliente.getNombre() + " " + cliente.getApellidos();
            boolean penalizado = cliente.isEstaCastigado();
            boolean penalizadoPerm = cliente.isEstaVetado();

            //guardamos en un array de Object el resultado
            Object[] row = {
                idCliente,
                dni,
                nombre,
                penalizado,
                penalizadoPerm};
            modelo.addRow(row); //añadimos una fila
        }

    }

    /**
     * Método que llena la tabla con el ArrayList sanciones
     *
     * @param tabla tablaSancion de VentanaSanciones.
     */
    public void llenarTablaSanciones(javax.swing.JTable tabla) {
        //Recuperamos el modelo de la tabla para poder modificarlo
        DefaultTableModel modelo = (DefaultTableModel) tabla.getModel();
        SimpleDateFormat formateoFecha = new SimpleDateFormat("dd-MM-yyyy");

        modelo.setRowCount(0); //vaciamos la tabla

        //Recorremos cada sanción para meterla en la tabla
        for (Sancion sancion : this.sanciones) {
            int idSancion = sancion.getId();
            String dni = sancion.getDni();
            String motivo = sancion.getMotivo();
            java.util.Date fechaFin = sancion.getFinSancion();
            String sFechaFin = formateoFecha.format(fechaFin);

            //guardamos en un array de Object el resultado
            Object[] row = {
                idSancion,
                dni,
                sFechaFin,
                motivo};
            modelo.addRow(row); //añadimos una fila
        }

    }

    /**
     * Metodo que perdona al cliente reduciendo en 1 las sanciones, borra la
     * sanción, y si no le quedan más sanciones activas le quita el estado
     * estaPenalizado
     *
     * @param idCliente ID de cliente a perdonar.
     * @param idSancion Sanción que se perdona.
     * @param conexion Conexión a la BBDD.
     * @return true si perdona, false si no.
     */
    public boolean perdonarCliente(int idCliente, int idSancion,
            Connection conexion) {
        boolean clientePerdonado = false;

        //Las sentencias se ponen en orden de uso
        String sqlSelectSancion = "SELECT idSancion FROM Sancion "
                + "WHERE idSancion = ? AND idCliente = ?";
        String sqlClientePerdonar = "UPDATE Cliente "
                + "SET numSanciones = numSanciones - 1 "
                + "WHERE idUsuario = ?";
        String sqlDeleteSancion = "DELETE FROM Sancion WHERE idSancion = ?";
        String sqlCountSancionesActivas = "SELECT COUNT(*) "
                + "FROM Sancion "
                + "WHERE idCliente = ? AND estaActivo = true";
        String sqlQuitarSancion = "UPDATE Cliente "
                + "SET estaPenalizado = false "
                + "WHERE idUsuario = ?";

        PreparedStatement sentenciaSelectSancion = null;
        PreparedStatement sentenciaClientePerdonar = null;
        PreparedStatement sentenciaDeleteSancion = null;
        PreparedStatement sentenciaCountSancionesActivas = null;;
        PreparedStatement senteciaQuitarSancion = null;

        ResultSet rsSancion = null;
        ResultSet rsCount = null;
        int iClientesPerdonados = 0;
        int iSancionesBorradas = 0;
        int iSancionesActivas = 0;
        String sDni = "";
        try {

            //primero se comprueba que existe la sanción
            sentenciaSelectSancion = conexion.prepareStatement(sqlSelectSancion);
            sentenciaSelectSancion.setInt(1, idSancion);
            sentenciaSelectSancion.setInt(2, idCliente);
            rsSancion = sentenciaSelectSancion.executeQuery();
            if (rsSancion.next()) {

                rsSancion.close();
                sentenciaSelectSancion.close();

                //Se reduce en 1 las sanciones
                sentenciaClientePerdonar = conexion.prepareStatement(sqlClientePerdonar);
                sentenciaClientePerdonar.setInt(1, idCliente);
                iClientesPerdonados = sentenciaClientePerdonar.executeUpdate();
                sentenciaClientePerdonar.close();

                if (iClientesPerdonados > 0) {
                    //Si ocurre se borra la sanción
                    sentenciaDeleteSancion = conexion.prepareStatement(sqlDeleteSancion);
                    sentenciaDeleteSancion.setInt(1, idSancion);
                    iSancionesBorradas = sentenciaDeleteSancion.executeUpdate();

                    sentenciaDeleteSancion.close();

                    if (iSancionesBorradas > 0) {
                        //Aquí ya se considera perdonado el cliente
                        clientePerdonado = true;

                        //Se comprueba si tiene más sanciones activas
                        sentenciaCountSancionesActivas
                                = conexion.prepareStatement(sqlCountSancionesActivas);
                        sentenciaCountSancionesActivas.setInt(1, idCliente);
                        rsCount = sentenciaCountSancionesActivas.executeQuery();
                        if (rsCount.next()) {
                            iSancionesActivas = rsCount.getInt(1);

                            rsCount.close();
                            sentenciaCountSancionesActivas.close();
                            //Si no tiene mas sanciones activas estaPenalizado pasa a false
                            if (iSancionesActivas == 0) {
                                senteciaQuitarSancion = conexion.prepareStatement(sqlQuitarSancion);
                                senteciaQuitarSancion.setInt(1, idCliente);
                                senteciaQuitarSancion.executeUpdate();
                                senteciaQuitarSancion.close();
                            }
                        }

                    }

                }

                //Hace rollBack si no perdona.
                if (!clientePerdonado) {
                    conexion.rollback();
                }
            }
        } catch (SQLException ex) {
            try {
                clientePerdonado = false;
                conexion.rollback();
            } catch (SQLException ex1) {
            } finally {
                try {
                    conexion.close();
                } catch (SQLException ex1) {
                }
            }
        }
        return clientePerdonado;
    }

    /**
     * Método que sanciona un cliente, se inserta una sanción, se pone en
     * penalizado y se le suma +1 a numSanciones, si esta sanción le suma para
     * igualar el limite de sanciones también le bloquea permanentemente.
     *
     * @param idCliente ID cliente a sancionar.
     * @param motivo Motivo de la sanción.
     * @param conexion Conexión a la BBDD sql.
     * @return true si sanciona, false si no sanciona.
     */
    public boolean sancionarCliente(int idCliente, String motivo,
            Connection conexion) {
        boolean clienteSancionado = false;
        //Las sentencias estan en orden de uso.
        String sqlSelectCliente = "SELECT numSanciones, dni FROM Cliente "
                + "WHERE idUsuario = ?";
        String sqlInsertSancion = "INSERT INTO Sancion (idCliente, dni, motivo, diaFinSancion) "
                + "VALUES (?, ?, ?, ?)";
        String sqlClienteSancion = "UPDATE Cliente "
                + "SET estaPenalizado = true, numSanciones = numSanciones + 1 "
                + "WHERE idUsuario = ?";
        String sqlClienteBloqueo = "UPDATE Cliente "
                + "SET estaPenalizadoPerm = true "
                + "WHERE idUsuario = ?";

        PreparedStatement sentenciaSelectCliente = null;
        PreparedStatement sentenciaInsertSancion = null;
        PreparedStatement sentenciaClienteSancion = null;
        PreparedStatement sentenciaClienteBloqueo = null;

        ResultSet rsCliente = null;

        int iFilasAfectadas = 0;
        String sDni = "";
        int iSancionesUsuario = 0;
        try {

            sentenciaSelectCliente = conexion.prepareStatement(sqlSelectCliente);
            sentenciaSelectCliente.setInt(1, idCliente);
            rsCliente = sentenciaSelectCliente.executeQuery();
            //Primero obtenemos el dni y numSanciones por que lo necesitamos
            if (rsCliente.next()) {
                iSancionesUsuario = rsCliente.getInt(1);
                sDni = rsCliente.getString(2);

                rsCliente.close();
                sentenciaSelectCliente.close();

                Date hoy = new Date(System.currentTimeMillis());

                //conseguimos la fecha de fin de sanción
                Calendar calendar = Calendar.getInstance();
                calendar.add(Calendar.DAY_OF_MONTH, this.tiempoSancion);
                Date finSancion = new Date(calendar.getTimeInMillis());

                //Insertamos informacion necesaria para insertar una sanción
                sentenciaInsertSancion = conexion.prepareStatement(sqlInsertSancion);
                sentenciaInsertSancion.setInt(1, idCliente);
                sentenciaInsertSancion.setString(2, sDni);
                sentenciaInsertSancion.setString(3, motivo);
                sentenciaInsertSancion.setDate(4, finSancion);
                sentenciaInsertSancion.executeUpdate();
                sentenciaInsertSancion.close();

                //Le sumamos 1 al numero de sanciones y lo ponemos en penalizado
                sentenciaClienteSancion = conexion.prepareStatement(sqlClienteSancion);
                sentenciaClienteSancion.setInt(1, idCliente);
                iFilasAfectadas = sentenciaClienteSancion.executeUpdate();
                sentenciaClienteSancion.close();

                if (iFilasAfectadas > 0) { //Compruebo si lo he sancionado
                    clienteSancionado = true;
                }

                //Si esta sanción llega al limite de sanciones, bloquea al usuario.
                if ((iSancionesUsuario + 1) >= this.maxSancionesPorUsuario) {
                    sentenciaClienteBloqueo = conexion.prepareStatement(sqlClienteBloqueo);
                    sentenciaClienteBloqueo.setInt(1, idCliente);
                    sentenciaClienteBloqueo.executeUpdate();
                    sentenciaClienteBloqueo.close();

                }

                if (!clienteSancionado) {
                    conexion.rollback();
                }
            }
        } catch (SQLException ex) {
            try {
                clienteSancionado = false;
                conexion.rollback();
            } catch (SQLException ex1) {
            } finally {
                try {
                    conexion.close();
                } catch (SQLException ex1) {
                }
            }
        }
        return clienteSancionado;
    }

    /**
     * Metodo que bloquea a un cliente.
     *
     * @param idCliente Cliente a bloquear.
     * @param conexion Conexion a la BBDD.
     * @return true si bloquea, false si no
     * @throws SQLException
     */
    public boolean bloquearCliente(int idCliente,
            Connection conexion) throws SQLException {
        String sqlBloquear = "UPDATE Cliente SET estaPenalizadoPerm = true "
                + "WHERE idUsuario = ?";
        boolean bloqueado = false;
        int filasAfectadas = 0;

        PreparedStatement sentencia = null;

        //Se introduce el id del cliente al que se bloquea
        sentencia = conexion.prepareStatement(sqlBloquear);
        sentencia.setInt(1, idCliente);

        filasAfectadas = sentencia.executeUpdate();

        //Si lo modifica devuelve true
        if (filasAfectadas > 0) {
            bloqueado = true;
        }
        sentencia.close();

        return bloqueado;
    }

    /**
     * Metodo que desbloquea a un cliente.
     *
     * @param idCliente Cliente a desbloquear.
     * @param conexion Conexion a la BBDD.
     * @return true si desbloquea, false si no
     * @throws SQLException
     */
    public boolean desbloquearCliente(int idCliente,
            Connection conexion) throws SQLException {
        String sqlDesbloquear = "UPDATE Cliente SET estaPenalizadoPerm = false "
                + "WHERE idUsuario = ?";
        boolean desbloqueado = false;
        int filasAfectadas = 0;

        PreparedStatement sentencia = null;

        //Se introduce el id del cliente al que se desbloquea
        sentencia = conexion.prepareStatement(sqlDesbloquear);
        sentencia.setInt(1, idCliente);

        filasAfectadas = sentencia.executeUpdate();

        //Si lo modifica devuelve true
        if (filasAfectadas > 0) {
            desbloqueado = true;
        }
        sentencia.close();

        return desbloqueado;
    }

    /**
     * Metodo que pone a false estaPenalizado cuando el cliente no tiene
     * sanciones activas, ni prestamos pasados y tiene estaPenalizado en true,
     * es un metodo que desbloquea al cliente.
     *
     * @param idCliente id Cliente a desbloquear
     * @param conexion Conexión a la BBDD
     * @return true si desbloquea, false si no lo hace.
     * @throws SQLException Error de conexion a la BBDD.
     */
    public boolean desbloquearSinSancionCliente(int idCliente,
            Connection conexion) throws SQLException {
        String sqlCountSancionesActivas = "SELECT COUNT(*) "
                + "FROM Sancion "
                + "WHERE estaActivo = true AND idCliente = ?";
        String sqlCountPrestamosPasados = "SELECT COUNT(*) FROM Prestamo "
                + "WHERE finPrestamo < CURDATE() AND idCliente = ?";
        String sqlDesbloquear = "UPDATE Cliente SET estaPenalizado = false "
                + "WHERE estaPenalizado = true AND idUsuario = ?";
        boolean desbloqueado = false;

        PreparedStatement sentenciaCountSancionesActivas = null;
        PreparedStatement sentenciaCountPrestamosPasados = null;
        PreparedStatement sentenciaDesbloquear = null;
        int iSancionesActivas = 0;
        int iPrestamosPasados = 0;
        int iClientesDesbloqueados = 0;

        ResultSet rsCountSancionesActivas = null;
        ResultSet rsCountPrestamosPasados = null;

        //Se realiza busqueda de si tiene sanciones activas
        sentenciaCountSancionesActivas = conexion.prepareStatement(sqlCountSancionesActivas);
        sentenciaCountSancionesActivas.setInt(1, idCliente);

        rsCountSancionesActivas = sentenciaCountSancionesActivas.executeQuery();

        //Si lo modifica devuelve true
        if (rsCountSancionesActivas.next()) {
            iSancionesActivas = rsCountSancionesActivas.getInt(1);

            rsCountSancionesActivas.close();
            sentenciaCountSancionesActivas.close();

            //si no tiene sanciones activas. Se mira si tiene prestamos pasados
            if (iSancionesActivas == 0) {
                sentenciaCountPrestamosPasados
                        = conexion.prepareStatement(sqlCountPrestamosPasados);
                sentenciaCountPrestamosPasados.setInt(1, idCliente);

                rsCountPrestamosPasados = sentenciaCountPrestamosPasados.executeQuery();

                if (rsCountPrestamosPasados.next()) {
                    iPrestamosPasados = rsCountPrestamosPasados.getInt(1);

                    rsCountPrestamosPasados.close();
                    sentenciaCountPrestamosPasados.close();

                    //Si no tiene prestamos pasados lo intenta desbloquear si estaPenalizado = true
                    if (iPrestamosPasados == 0) {
                        sentenciaDesbloquear = conexion.prepareStatement(sqlDesbloquear);
                        sentenciaDesbloquear.setInt(1, idCliente);

                        iClientesDesbloqueados = sentenciaDesbloquear.executeUpdate();

                        sentenciaDesbloquear.close();

                    }

                }

            }
        }
        //Si ha desbloqueado un cliente devuelve true el metodo.
        if (iClientesDesbloqueados > 0) {
            desbloqueado = true;
        }

        return desbloqueado;
    }

}

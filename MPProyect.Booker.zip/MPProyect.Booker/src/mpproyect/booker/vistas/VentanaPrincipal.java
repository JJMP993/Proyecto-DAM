package mpproyect.booker.vistas;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;
import java.util.logging.Level;
import java.util.logging.Logger;
import mpproyect.booker.Controlador.Login;
import mpproyect.booker.Controlador.Libreria;

/**
 * Ventana que es la ventana principal de la aplicación. La ventana solo activa
 * los botones en función de los permisos del usuario. En la tabla de la ventana
 * se pueden ver los prestamos pasados.
 * 
 * @author José Javier Morillas Pérez
 */
public class VentanaPrincipal extends javax.swing.JFrame {

    private Login usuario;
    private Libreria libreria;
    private VentanaPrestamos ventanaPrestamos = null;
    private VentanaDevolucion ventanaDevolucion = null;
    private VentanaColecciones ventanaColecciones = null;
    private VentanaClientesTrabajadores ventanaClientesTrabajadores = null;
    private VentanaSanciones ventanaSanciones = null;
    private VentanaConfiguracion ventanaConfiguracion = null;
    private VentanaPermisos ventanaPermisos = null;

    public Login getUsuario() {
        return usuario;
    }

    /**
     * Metodo que permite pasarle parametros del usuario a esta ventana Ademas
     * comprueba los permisos del usuario y activa los botones según los
     * permisos, busca las sanciones terminadas y las acaba y también bloquea
     * que clientes con prestamos pasados puedan sacar prestamos.
     *
     * @param usuario objeto de tipo login que representa la conexión
     */
    public void setUsuario(Login usuario) {
        this.usuario = usuario;
        Connection conection = null;
        try {
            conection = this.usuario.getConexionBBDD();
        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } catch (ClassNotFoundException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        }
        if (conection != null) {
            try {
                LocalDateTime hoy = LocalDateTime.now();
                String sHoy = hoy.getDayOfMonth() + "/" + hoy.getMonthValue()
                        + "/" + hoy.getYear();
                this.usuario.permisosPrincipal(btPrestamo, btDevolucion, btLibros, btUsuarios,
                        btSanciones, btConfiguracion, btPermisos, conection);
                // Ponemos la id del rol en el texto y el nombre de usuario
                this.txtNivelRol.setText(Integer.toString(this.usuario.getRol()));
                this.txtNombreTrabajador.setText(this.usuario.getUsuario());
                this.txtFecha.setText(sHoy);

            } catch (SQLException ex) {
                Logger.getLogger(VentanaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            } finally {
                try {
                    conection.close();
                } catch (SQLException ex) {
                    Logger.getLogger(VentanaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
        }
        Connection conexionInicial = null;
        try {
            conexionInicial = usuario.getConexionBBDD();
            libreria = new Libreria(conexionInicial);

        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } catch (ClassNotFoundException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } finally {
            try {
                if (!conexionInicial.isClosed()) {
                    conexionInicial.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(VentanaPrincipal.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        Connection conexion = null;
        try {
            conexion = usuario.getConexionBBDD();
            libreria.finalizarSancionesCumplidas(conexion);
        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } catch (ClassNotFoundException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");

        }

        Connection conexion2 = null;
        try {
            try {
                conexion2 = usuario.getConexionBBDD();
            } catch (ClassNotFoundException ex) {
                this.txtRespuesta.setText("Error en la conexión a la BBDD");
            }
            libreria.consultarPrestamosPasados(conexion2);
        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } finally {
            try {
                if (!conexion2.isClosed()) {
                    conexion2.close();
                }
            } catch (SQLException ex) {
                this.txtRespuesta.setText("Error en la conexión a la BBDD");
            }
        }

        Connection conexion3 = null;
        try {
            conexion3 = usuario.getConexionBBDD();
            libreria.prohibirPrestamos(conexion3);
        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        } catch (ClassNotFoundException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");

        }
        this.libreria.llenarTablaPrincipal(tblDevoluciones);

    }

    public Libreria getLibreria() {
        return libreria;
    }

    public void setLibreria(Libreria libreria) {
        this.libreria = libreria;
        try {
            Connection conexion = null;
            try {
                conexion = usuario.getConexionBBDD();
            } catch (ClassNotFoundException ex) {
                this.txtRespuesta.setText("Error en la conexión a la BBDD");
            }
            this.libreria.consultarPrestamosPasados(conexion);
        } catch (SQLException ex) {
            this.txtRespuesta.setText("Error en la conexión a la BBDD");
        }
        this.libreria.llenarTablaPrincipal(tblDevoluciones);

    }

    /**
     * Creates new form VentanaPrincipal
     */
    public VentanaPrincipal() {
        initComponents();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        Fondo = new javax.swing.JPanel();
        panelTitulo = new javax.swing.JPanel();
        titulo = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txtNombreTrabajador = new javax.swing.JLabel();
        txtNivelRol = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txtFecha = new javax.swing.JLabel();
        panelMenu = new javax.swing.JPanel();
        btPrestamo = new javax.swing.JButton();
        btDevolucion = new javax.swing.JButton();
        btLibros = new javax.swing.JButton();
        btUsuarios = new javax.swing.JButton();
        btSanciones = new javax.swing.JButton();
        btConfiguracion = new javax.swing.JButton();
        btPermisos = new javax.swing.JButton();
        btCerrarSesion = new javax.swing.JButton();
        btSalir = new javax.swing.JButton();
        panelCentral = new javax.swing.JScrollPane();
        tblDevoluciones = new javax.swing.JTable();
        txtRespuesta = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Booker: Gestor de prestamos");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosed(java.awt.event.WindowEvent evt) {
                formWindowClosed(evt);
            }
        });

        Fondo.setBackground(new java.awt.Color(155, 190, 200));
        Fondo.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelTitulo.setBackground(new java.awt.Color(22, 72, 99));

        titulo.setBackground(new java.awt.Color(102, 102, 255));
        titulo.setFont(new java.awt.Font("Roboto", 0, 18)); // NOI18N
        titulo.setForeground(new java.awt.Color(221, 242, 253));
        titulo.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        titulo.setText("Booker: Gestor de prestamos");

        jLabel2.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(221, 242, 253));
        jLabel2.setText("Trabajador:");

        jLabel3.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(221, 242, 253));
        jLabel3.setText("Nivel de rol:");

        txtNombreTrabajador.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        txtNombreTrabajador.setForeground(new java.awt.Color(221, 242, 253));
        txtNombreTrabajador.setText("usuario del trabajador");

        txtNivelRol.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        txtNivelRol.setForeground(new java.awt.Color(221, 242, 253));
        txtNivelRol.setText("00");

        jLabel5.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(221, 242, 253));
        jLabel5.setText("Día");

        txtFecha.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        txtFecha.setForeground(new java.awt.Color(221, 242, 253));
        txtFecha.setText("15/02/1993");

        javax.swing.GroupLayout panelTituloLayout = new javax.swing.GroupLayout(panelTitulo);
        panelTitulo.setLayout(panelTituloLayout);
        panelTituloLayout.setHorizontalGroup(
            panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTituloLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jLabel3, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(txtNivelRol, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtNombreTrabajador, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(94, 94, 94)
                .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(panelTituloLayout.createSequentialGroup()
                        .addGap(123, 123, 123)
                        .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(102, 102, 102))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, panelTituloLayout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtFecha)
                        .addGap(94, 94, 94))))
        );
        panelTituloLayout.setVerticalGroup(
            panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelTituloLayout.createSequentialGroup()
                .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(titulo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(panelTituloLayout.createSequentialGroup()
                        .addGap(0, 0, Short.MAX_VALUE)
                        .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel2)
                            .addComponent(txtNombreTrabajador, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(panelTituloLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel3)
                            .addComponent(txtNivelRol, javax.swing.GroupLayout.PREFERRED_SIZE, 15, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGap(0, 4, Short.MAX_VALUE))
            .addGroup(panelTituloLayout.createSequentialGroup()
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txtFecha, javax.swing.GroupLayout.PREFERRED_SIZE, 14, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        Fondo.add(panelTitulo, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 830, 40));

        panelMenu.setBackground(new java.awt.Color(66, 125, 157));

        btPrestamo.setBackground(new java.awt.Color(221, 242, 253));
        btPrestamo.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btPrestamo.setForeground(new java.awt.Color(22, 72, 99));
        btPrestamo.setText("Prestamos");
        btPrestamo.setEnabled(false);
        btPrestamo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPrestamoActionPerformed(evt);
            }
        });

        btDevolucion.setBackground(new java.awt.Color(221, 242, 253));
        btDevolucion.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btDevolucion.setForeground(new java.awt.Color(22, 72, 99));
        btDevolucion.setText("Devoluciones");
        btDevolucion.setEnabled(false);
        btDevolucion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btDevolucionActionPerformed(evt);
            }
        });

        btLibros.setBackground(new java.awt.Color(221, 242, 253));
        btLibros.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btLibros.setForeground(new java.awt.Color(22, 72, 99));
        btLibros.setText("Libros");
        btLibros.setEnabled(false);
        btLibros.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btLibrosActionPerformed(evt);
            }
        });

        btUsuarios.setBackground(new java.awt.Color(221, 242, 253));
        btUsuarios.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btUsuarios.setForeground(new java.awt.Color(22, 72, 99));
        btUsuarios.setText("Clientes y Personal");
        btUsuarios.setEnabled(false);
        btUsuarios.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btUsuariosActionPerformed(evt);
            }
        });

        btSanciones.setBackground(new java.awt.Color(221, 242, 253));
        btSanciones.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btSanciones.setForeground(new java.awt.Color(22, 72, 99));
        btSanciones.setText("Sanciones");
        btSanciones.setEnabled(false);
        btSanciones.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSancionesActionPerformed(evt);
            }
        });

        btConfiguracion.setBackground(new java.awt.Color(221, 242, 253));
        btConfiguracion.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btConfiguracion.setForeground(new java.awt.Color(22, 72, 99));
        btConfiguracion.setText("Configuración");
        btConfiguracion.setEnabled(false);
        btConfiguracion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btConfiguracionActionPerformed(evt);
            }
        });

        btPermisos.setBackground(new java.awt.Color(221, 242, 253));
        btPermisos.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btPermisos.setForeground(new java.awt.Color(22, 72, 99));
        btPermisos.setText("Permisos");
        btPermisos.setEnabled(false);
        btPermisos.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btPermisosActionPerformed(evt);
            }
        });

        btCerrarSesion.setBackground(new java.awt.Color(221, 242, 253));
        btCerrarSesion.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btCerrarSesion.setForeground(new java.awt.Color(22, 72, 99));
        btCerrarSesion.setText("Cerrar Sesión");
        btCerrarSesion.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btCerrarSesionActionPerformed(evt);
            }
        });

        btSalir.setBackground(new java.awt.Color(221, 242, 253));
        btSalir.setFont(new java.awt.Font("Roboto", 1, 12)); // NOI18N
        btSalir.setForeground(new java.awt.Color(22, 72, 99));
        btSalir.setText("Salir");
        btSalir.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btSalirActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelMenuLayout = new javax.swing.GroupLayout(panelMenu);
        panelMenu.setLayout(panelMenuLayout);
        panelMenuLayout.setHorizontalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addContainerGap()
                .addGroup(panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btSalir, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btCerrarSesion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btPermisos, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btConfiguracion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btSanciones, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btUsuarios, javax.swing.GroupLayout.DEFAULT_SIZE, 208, Short.MAX_VALUE)
                    .addComponent(btPrestamo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btDevolucion, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(btLibros, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        panelMenuLayout.setVerticalGroup(
            panelMenuLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(panelMenuLayout.createSequentialGroup()
                .addGap(50, 50, 50)
                .addComponent(btPrestamo)
                .addGap(18, 18, 18)
                .addComponent(btDevolucion)
                .addGap(18, 18, 18)
                .addComponent(btLibros)
                .addGap(18, 18, 18)
                .addComponent(btUsuarios)
                .addGap(18, 18, 18)
                .addComponent(btSanciones)
                .addGap(18, 18, 18)
                .addComponent(btConfiguracion)
                .addGap(18, 18, 18)
                .addComponent(btPermisos)
                .addGap(18, 18, 18)
                .addComponent(btCerrarSesion)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btSalir)
                .addContainerGap(70, Short.MAX_VALUE))
        );

        Fondo.add(panelMenu, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 220, 450));

        tblDevoluciones = new javax.swing.JTable(){
            public boolean isCellEditable(int rowIndex, int colIndex){
                return false;
            }
        };
        tblDevoluciones.setAutoCreateRowSorter(true);
        tblDevoluciones.setFont(new java.awt.Font("Roboto", 0, 12)); // NOI18N
        tblDevoluciones.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null},
                {null, null, null, null, null, null},
                {null, null, null, null, null, null}
            },
            new String [] {
                "ID Usuario", "Nombre", "ID Libro", "Libro", "Vencimiento", "ID Prestamo"
            }
        ));
        tblDevoluciones.setToolTipText("");
        tblDevoluciones.setColumnSelectionAllowed(true);
        tblDevoluciones.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tblDevoluciones.setShowHorizontalLines(true);
        tblDevoluciones.getTableHeader().setReorderingAllowed(false);
        panelCentral.setViewportView(tblDevoluciones);
        tblDevoluciones.getColumnModel().getSelectionModel().setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        if (tblDevoluciones.getColumnModel().getColumnCount() > 0) {
            tblDevoluciones.getColumnModel().getColumn(0).setMaxWidth(70);
            tblDevoluciones.getColumnModel().getColumn(2).setMaxWidth(50);
            tblDevoluciones.getColumnModel().getColumn(4).setMaxWidth(80);
            tblDevoluciones.getColumnModel().getColumn(5).setMinWidth(85);
            tblDevoluciones.getColumnModel().getColumn(5).setMaxWidth(85);
        }

        Fondo.add(panelCentral, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 50, 590, 360));

        txtRespuesta.setFont(new java.awt.Font("Roboto", 0, 14)); // NOI18N
        txtRespuesta.setForeground(new java.awt.Color(22, 72, 99));
        txtRespuesta.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Fondo.add(txtRespuesta, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 420, 590, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Fondo, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btPrestamoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPrestamoActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaPrestamos == null) {
                ventanaPrestamos = new VentanaPrestamos();
                ventanaPrestamos.setLibreria(libreria);
                ventanaPrestamos.setUsuario(usuario);

                ventanaPrestamos.setVisible(true);
            } else {
                ventanaPrestamos.setLibreria(libreria);
                ventanaPrestamos.setUsuario(usuario);

                ventanaPrestamos.setVisible(true);
            }

        }
    }//GEN-LAST:event_btPrestamoActionPerformed

    private void btDevolucionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btDevolucionActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaDevolucion == null) {
                ventanaDevolucion = new VentanaDevolucion();
                ventanaDevolucion.setLibreria(libreria);
                ventanaDevolucion.setUsuario(usuario);
                ventanaDevolucion.setVisible(true);
                this.dispose();
            } else {
                ventanaDevolucion.setLibreria(libreria);
                ventanaDevolucion.setUsuario(usuario);
                ventanaDevolucion.setVisible(true);
                this.dispose();
            }
        }
    }//GEN-LAST:event_btDevolucionActionPerformed

    private void btLibrosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btLibrosActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaColecciones == null) {
                ventanaColecciones = new VentanaColecciones();
                ventanaColecciones.setLibreria(libreria);
                ventanaColecciones.setUsuario(usuario);
                ventanaColecciones.setVisible(true);
            } else {
                ventanaColecciones.setUsuario(usuario);
                ventanaColecciones.setLibreria(libreria);
                ventanaColecciones.setVisible(true);
            }
        }

    }//GEN-LAST:event_btLibrosActionPerformed

    private void btUsuariosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btUsuariosActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaClientesTrabajadores == null) {
                ventanaClientesTrabajadores = new VentanaClientesTrabajadores();
                ventanaClientesTrabajadores.setLibreria(libreria);
                ventanaClientesTrabajadores.setUsuario(usuario);
                ventanaClientesTrabajadores.setVisible(true);
            } else {
                ventanaClientesTrabajadores.setLibreria(libreria);
                ventanaClientesTrabajadores.setUsuario(usuario);
                ventanaClientesTrabajadores.setVisible(true);
            }
        }
    }//GEN-LAST:event_btUsuariosActionPerformed

    private void btSancionesActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSancionesActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaSanciones == null) {
                ventanaSanciones = new VentanaSanciones();
                ventanaSanciones.setLibreria(libreria);
                ventanaSanciones.setUsuario(usuario);
                ventanaSanciones.setVisible(true);
            } else {
                ventanaSanciones.setLibreria(libreria);
                ventanaSanciones.setUsuario(usuario);
                ventanaSanciones.setVisible(true);
            }
        }
    }//GEN-LAST:event_btSancionesActionPerformed

    private void btConfiguracionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btConfiguracionActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaConfiguracion == null) {
                ventanaConfiguracion = new VentanaConfiguracion();
                ventanaConfiguracion.setUsuario(usuario);
                ventanaConfiguracion.setVisible(true);
                this.dispose();
            } else {
                ventanaConfiguracion.setUsuario(usuario);
                ventanaConfiguracion.setVisible(true);
                this.dispose();
            }
        }
    }//GEN-LAST:event_btConfiguracionActionPerformed

    private void btPermisosActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btPermisosActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {
            if (ventanaPermisos == null) {
                ventanaPermisos = new VentanaPermisos();
                ventanaPermisos.setUsuario(usuario);
                ventanaPermisos.setVisible(true);
                this.dispose();
            } else {
                ventanaPermisos.setUsuario(usuario);
                ventanaPermisos.setVisible(true);
                this.dispose();
            }
        }
    }//GEN-LAST:event_btPermisosActionPerformed

    private void btCerrarSesionActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btCerrarSesionActionPerformed
        // TODO add your handling code here:
        if (usuario.isEstaConectado()) {

            VentanaLogin ventanaPermisos = new VentanaLogin();
            usuario.setEstaConectado(false);
            usuario.setUsuario(null);
            usuario.setPassword(null);
            ventanaPermisos.setUsuario(usuario);
            ventanaPermisos.setVisible(true);
            this.dispose();

        }
    }//GEN-LAST:event_btCerrarSesionActionPerformed

    private void btSalirActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btSalirActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btSalirActionPerformed

    private void formWindowClosed(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosed
        // TODO add your handling code here:
        if (ventanaClientesTrabajadores != null) {
            ventanaClientesTrabajadores.dispose();
        }
        if (ventanaColecciones != null) {
            ventanaColecciones.dispose();
        }
        if (ventanaClientesTrabajadores != null) {
            ventanaClientesTrabajadores.dispose();
        }
        if (ventanaClientesTrabajadores != null) {
            ventanaClientesTrabajadores.dispose();
        }
        if (ventanaSanciones != null) {
            ventanaSanciones.dispose();
        }
    }//GEN-LAST:event_formWindowClosed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(VentanaPrincipal.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new VentanaPrincipal().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fondo;
    private javax.swing.JButton btCerrarSesion;
    private javax.swing.JButton btConfiguracion;
    private javax.swing.JButton btDevolucion;
    private javax.swing.JButton btLibros;
    private javax.swing.JButton btPermisos;
    private javax.swing.JButton btPrestamo;
    private javax.swing.JButton btSalir;
    private javax.swing.JButton btSanciones;
    private javax.swing.JButton btUsuarios;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane panelCentral;
    private javax.swing.JPanel panelMenu;
    private javax.swing.JPanel panelTitulo;
    private javax.swing.JTable tblDevoluciones;
    private javax.swing.JLabel titulo;
    private javax.swing.JLabel txtFecha;
    private javax.swing.JLabel txtNivelRol;
    private javax.swing.JLabel txtNombreTrabajador;
    private javax.swing.JLabel txtRespuesta;
    // End of variables declaration//GEN-END:variables
}
